---
title: Unittest框架
date: 2018-08-02 09:11:39
tags:
---

## Unittest框架                        
- python自带的单元测试框架，java自带的单元框架Junit
- 单元测试的本质：代码测试代码；原理：调用源代码，对比预期结果和实际结果
- 特别注意：unittest 框架识别被测代码的方式：测试代码方法名需以test开头

## 核心API		
```python
setUP() 		# 初始化；特点：每一条测试用例执行前就会执行初始化
tearDown() 		# 资源回收；特点：每一条测试用例执行后就会执行资源回收  
setUpClass() 		# 初始化；特点：所有测试用例执行前执行初始化
tearDownClass() 	# 资源回收；特点：所有用例执行后执行资源回收
```
## 断言
```python
assertEqual(a,b,msg)		a == b
assertGreater(a,b,msg)     	a > b
assertLess(a,b,msg)  		a < b 
```
## TestSuite 测试集
```python
suite = unittest,TestSuite() 							# 实例化测试集
suite.addTests(unittest.TestLoader().loadTestsFromTestCase( 类名 ))		# 加载整个类中的测试用例进入测试集
suite.addTests(unittest.TestLoader().loadTestsFromName(‘模块名.类名.方法名’))	# 记载指定某个模块下的某个类下的方法/用例
suite.addTests(unittest.TestLoader().loadTestsFromName(‘模块名.类名’)) 		# 加载整个类中的测试用例进入测试集
suite.addTests(unittest.TestLoader().loadTestsFromModule(模块名))		# 加载整个模块的测试用例进入测试集，特别注意：需要导入本模
runner=unittest.TextTestRunner(verbosity=2)					# 实例化一个runner, verbosity：结果复杂度
runner.run(suite)								# 执行测试集
```
## 装饰器
```        python
@unittest.skip					# 强制跳过
@unittest.skipIf(1<2,reason='1<2,跳过')		# 满足条件就跳过，True-跳过
@unittest.skipUnless(2<1,reason='1<2,跳过')	# 不满足条件就跳过，False-跳过
```
## TestResult  
```                        python
suite=unittest.TestSuite()			# 实例化测试集
suite.addTest(calc_Test('test_add01'))		# 加载单个测试用例到测试集中
r=unittest.TestResult()				# 实例化一个测试结果用于存储测试结果
suite.run(result=r)				# 以测试集方式执行测试
```
## TestRunner     
```                    python
suite=unittest.TestSuite()			# 实例化测试集
suite.addTest(calc_Test('test_add01'))		# 加载单个测试用例到测试集中
unittest.TextTestRunner().run(suite)		# 执行测试集
```
## 测试报告     
```                           python
# 系统自带生成报告
with open('report.txt','w') as file:
    unittest.TextTestRunner(stream=file,verbosity=2).run(suite)
# 利用第三方库HTMLTestRunner
with open('report.html','w',encoding='utf-8') as file:
    HTMLTestRunner(stream=file,verbosity=2,title='测试报告',description='计算器的测试报告').run(suite)
```

