---
title: Python面向对象
date: 2018-10-12 12:27:34
tags:
---

参考自：[https://github.com/Renskk/Python-100-Days/blob/master/Day16-20/16-20.Python%E8%AF%AD%E8%A8%80%E8%BF%9B%E9%98%B6.md](https://github.com/Renskk/Python-100-Days/blob/master/Day16-20/16-20.Python语言进阶.md)

## 面向对象设计原则

- 单一职责原则 （**S**RP）- 一个类只做该做的事情（类的设计要高内聚）
- 开闭原则 （**O**CP）- 软件实体应该对扩展开发对修改关闭
- 依赖倒转原则（DIP）- 面向抽象编程（在弱类型语言中已经被弱化）
- 里氏替换原则（**L**SP） - 任何时候可以用子类对象替换掉父类对象
- 接口隔离原则（**I**SP）- 接口要小而专不要大而全（Python中没有接口的概念）
- 合成聚合复用原则（CARP） - 优先使用强关联关系而不是继承关系复用代码
- 最少知识原则（迪米特法则，Lo**D**）- 不要给没有必然联系的对象发消息

> 说明：上面加粗的字母放在一起称为面向对象的**SOLID**原则。

## 装饰器

装饰器本质上是一个 Python 函数或类，它可以让其他函数或类在不需要做任何代码修改的前提下增加额外功能，装饰器的返回值也是一个函数/类对象。它经常用于有切面需求的场景，比如：插入日志、性能测试、事务处理、缓存、权限校验等场景，装饰器是解决这类问题的绝佳设计。有了装饰器，我们就可以抽离出大量与函数功能本身无关的雷同代码到装饰器中并继续重用。概括的讲，装饰器的作用就是为已经存在的对象添加额外的功能。 

引用自：https://foofish.net/python-decorator.html

### @property



```python
class Person:
    def __init__(self, name, age):
        self._name = name
        self._age = age
        
    # 访问器 - getter方法
    @property
    def name(self):
        return self._name
    
    @property
    def age(self):
        return self._age
    # 访问器 - setter方法
    @age.setter
    def age(self, age):
        self._age = age
        
    def play(self):
		print(f'{self._name}今年{self._age}岁！')

if __name__ == '__main__':
    person = Person('赵四', 12)
    person.play()
    person.age = 22
    person.play()
```

## \__slots__

在类中定义\__slots__变量来进行限定自定义类型的对象只能绑定某些属性

```python
class Person:
    
    # 限定Person对象只能绑定_name, _age和_gender属性
    __slots__ = ('_name', '_age', '_gender')
    def __init__(self, name, age):
        self._name = name
        self._age = age
        
    # 访问器 - getter方法
    @property
    def name(self):
        return self._name
    
    @property
    def age(self):
        return self._age
    # 访问器 - setter方法
    @age.setter
    def age(self, age):
        self._age = age
        
    def play(self):
		print(f'{self._name}今年{self._age}岁！')
if __name__ == '__main__':
    person = Person('赵四', 12)
    person.play()
    person.age = 22
    person.play()
    # AttributeError: 'Person' object has no attribute 'sex'
    person.sex = '女'
    print(person.sex)
```

## 静态方法

静态方法是属于这个类，但不属于这个类的对象

```python
class Test:

    def __init__(self, name, age, nationality):
        self.name = name
        self.age = age
        self.nationality = nationality

    @staticmethod
    def is_chinese(nationality):
        return True if nationality == 'chinese' else False

    def play(self):
        print(f'{self.name}, {self.age}years is {self.nationality}')

if __name__ == '__main__':
    # 静态方法和类方法都是通过给类发消息来调用的
    if Test.is_chinese('chinese'):
        print('China')
        print(Test('tom', 12, 'chinese').play())
    else:
        print('Foreign')
```

## 类方法

Python可以在类中定义类方法，类方法的第一个参数约定名为cls，它代表的是当前类相关的信息的对象（类本身也是一个对象，有的地方也称之为类的元数据对象），通过这个参数我们可以获取和类相关的信息并且可以创建出类的对象。

```python
from time import time, localtime, sleep


class Clock(object):
    """数字时钟"""

    def __init__(self, hour=0, minute=0, second=0):
        self._hour = hour
        self._minute = minute
        self._second = second

    @classmethod
    def now(cls):
        ctime = localtime(time())
        return cls(ctime.tm_hour, ctime.tm_min, ctime.tm_sec)

    def run(self):
        """走字"""
        self._second += 1
        if self._second == 60:
            self._second = 0
            self._minute += 1
            if self._minute == 60:
                self._minute = 0
                self._hour += 1
                if self._hour == 24:
                    self._hour = 0

    def show(self):
        """显示时间"""
        return '%02d:%02d:%02d' % \
               (self._hour, self._minute, self._second)

def main():
    # 通过类方法创建对象并获取系统时间
    clock = Clock.now()
    while True:
        print(clock.show())
        sleep(1)
        clock.run()
if __name__ == '__main__':
    main()
```

## 类、静态、实例方法区别

类方法不论是否为实例对象调用，都属于类的方法

静态方法无论是否为实例对象调用，都属于类的函数

实例方法当调用对象为类的实例时，它属于类的方法，反之则为函数

```python
class Test:

    def a(self):
        # return self.b()			# 静态方法可以使用self.函数名在类中调研
        print('这是实例函数')
    
    @staticmethod
    def b():
        print('这是静态方法')

    @classmethod
    def c(cls):
        pass
        # print('这是类方法')

if __name__ == "__main__":
    t = Test()
    print(type(t.a))				# <class 'method'>
    print(type(Test.a))				# <class 'function'>
    Test.a(t)						# 这是实例函数
    Test.a('hello')					# 这是实例函数
    print(type(Test.b))				# <class 'function'>
    print(type(t.b))				# <class 'function'>
    print(type(Test.c))				# <class 'method'>
    print(type(t.c))				# <class 'method'>
    
```



## 继承

一个类使用另外的类的非私有的属性和方法的时候，可以通过上面的方式，实现类的继承，来达到代码的复用

再有多个父类时如果父类里面有初始化属性，需要通过父类名.\__init__(self,参数列表)的方法实现属性的命名

在只有一个父类的情况下，还可以使用super()的方法调用父类的方法，和上一种方法的区别是super()只是一个对象，不需要再参数类别中添加self

```python
class Person:

    def __init__(self, name, age, sex):
        self.name = name
        self.age = age
        self.sex = sex

class student(Person):

    def __init__(self, name, age, sex, sno):
        super().__init__(name, age, sex)
        self.name = name
        self.age = age
        self.sex = sex
        self.sno = sno

    def show(self):
        print(f'学生信息：\n学号：{self.sno}\n姓名：{self.name}'
              f'\n年龄：{self.age}\n性别：{self.sex}\n')

class teacher(Person):

    def __init__(self, name, age, sex, tno):
        super().__init__(name, age, sex)
        self.name = name
        self.age = age
        self.sex = sex
        self.tno = tno

    def show(self):
        print(f'老师信息：\n编号：{self.tno}\n姓名：{self.name}'
              f'\n年龄：{self.age}\n性别：{self.sex}')

if __name__ == '__main__':
    student('tom', 12, '男', '001').show()
    teacher('tim', 32, '男', '100').show()
```

子类在继承了父类的方法后，可以对父类已有的方法给出新的实现版本，这个动作称之为方法重写（override）。通过方法重写我们可以让父类的同一个行为在子类中拥有不同的实现版本，当我们调用这个经过子类重写的方法时，不同的子类对象会表现出不同的行为，这个就是多态.

