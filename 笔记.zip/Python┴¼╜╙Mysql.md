---
title: Python连接Mysql
date: 2018-08-12 12:27:34
tags:
---
```python
STEP1:引包： #pip install pymql
Import pymySQL

STEP2:通过模块调用对应的方法获取一个连续的函数
#指明连接的数据库（host、user、password、databasesname、charset）
con = pymysql.connect (                                           )

STEP3:用连接对象调用方法获取一个可执行对象
cur = con.cursor()

STEP4:执行SQL语句
sql = （语句）
cur.execute(sql)
con.commit()
------------------------------------------
#cur.fetchone()  	# 获取元组第一个元素
#cur.fetchall() 	# 获取元组剩余的元素
#cur.fetchmany() 	# 获取全部元素
------------------------------------------

STEP5:关闭连接
cur.close()
con.close()
```

