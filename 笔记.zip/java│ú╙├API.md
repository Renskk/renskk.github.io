---
title: Java常用API	
date: 2019-07-31 12:21:02
tags:
---

# 基础API

## Object类

```java
public int hashCode()
// 哈希编码： 跟内存地址有关，根据内存地址按照哈希算法计算出一个数
// 两个字符串的内存不同，但是哈希编码可能一样 例如："Aa"和"BB" 。
--------------------------------------------------------
public final Class getClass()
// Class与反射有关，代表类的字节码对象
--------------------------------------------------------
public String toString()
// 重写该方法自定义对象的输出格式
--------------------------------------------------------
public boolean equals(Object obj)
// 引用类型比较相等，默认比地址
// 重写方法，按照属性值比较内容相等
--------------------------------------------------------
protected void finalize()
// 清理资源、记录日志
// 手动启动垃圾回收  System.gc()
-------------------------------------------------------- 
protected Object clone()
// 必须实现Cloneable接口（这个接口什么都没有） -- 标记接口
--------------------------------------------------------
```

## String类

- 概述

  - 字符串是由多个字符组成的一串数据（字符序列）
  - 字符串可以看作是字符数组

- 构造方法

  ```java
  public String()
  public String(byte[] bytes)
  public String(byte[] bytes, int offset, int length)
  public String(char[] value)
  public String(char[] value, int offset, int count)
  public String(String original)
  ```

- 判断功能

  ```java
  boolean equals(Object obj)
  // 判断两个字符串是否相等
  boolean equalsIgnoreCase(Object obj)
  // 判断两个字符串是否相等，不考虑大小写
  boolean contains(String str)
  // 是否包含某个字符串
  boolean startsWith(String str)
  // 判断字符串是否以某个字符串开始
  boolean endsWith(String str)
  // 判断字符串是否以某个字符串结尾
  boolean isEmpty()
  // 判断是否空字符串
  ```

- 获取功能

  ```java
  int length()
  // 字符串的长度
  char charAt(int index)
  // 返回字符串指定位置的字符
  int indexOf(int ch)
  // 找指定字符的下标
  int indexOf(String str)
  // 找指定字符串的下标
  int indexOf(int ch, int fromIndex)
  // 指定字符串下标位置
  int indexOf(String str, int fromIndex)
  String substring(int start)
  // 截取字符串，指定起始位置
  String substring(int start, int end)
  // 指定截取字符串的起始和结尾位置
  ```

- 转换功能

  ```java
  byte[] getBytes()
  // String 还原成字节数组
  char[] toCharArray()
  // String 转换成字符数组
  static String valueOf(char[] chs)
  // 字符数组变字符串
  static String valueOf(int i)
  // 整数转字符串
  // 最常用的是 整数加一个空字符 (str = 1+"";)
  String toLowerCase()
  // 字符串全部变小写
  String toUpperCase()
  // 字符串全部转小写
  String concat(String str)
  // 字符串拼接
  ```

- 其他功能

  替换功能

  ```java
  String replace(char old, char new)
  String replace(String old, String new)
  ```

  去除字符串两空格

  ```java
  String trim()
  ```

  按字典顺序比较两个字符串

  ```java
  int compareTo(String str)
  int compareToIgnoreCase(String str)
  ```

  

##  StringBuffer类

- 描述

  - StringBuffer主要帮助我们解决字符串拼接问题，因为每次字符串拼接都会构建新的对象，费时，费空间
  - 线程安全的可变字符序列

- StringBuffer和String的区别

  -  

- 构造方法

  ```java
  public StringBuffer()
  
  public StringBuffer(String str)
  ```

- 添加功能

  ```java
  public StringBuffer append(String str)
  public StringBuffer insert(int offset,String str)
  ```

- 删除功能

  ```java
  public StringBuffer deleteCharAt(int index)
  public StringBuffer delete(int start, int end)
  ```

- 替换功能

  ```java
  public StringBuffer replace(int start, int end, String str)
  ```

- 反转功能

  ```java
  public StringBuffer reverse()
  ```

- 截取功能

  ```java
  public String substring(int start)
  public String substring(int start, int end)
  ```

  

## String, StringBuffer, StringBuilder

- 区别
  - String : 不可字符串
  - StringBuffer, StringBuilder：可变字符串
    - StringBuffer：线程安全
    - StringBuilder：线程不安全，效率高



## Arrays类

- 概述

  - 针对数组进行操作的工具类
  - 提供了排序，查找等功能

- 成员方法

  ```java
  public static String toString(int[] a)
  public static void sort(int[] a)
  public static int binarySearch(int[] a, int key)
  // 二分查找
  ```

## 包装类

- 概述

  - 基本类型对应的引用类型
  - 主要用来做类型转换
- 基本类型和包装类型的对应
- Byte, Short, Integer, Long, Float, Double, Character, Boolean

## Integer类

- 概述

  Integer类在对象中包装了一个基本类型int的值

- 构造方法

  ```java
  public Integer(int value)
  public Integer(String s)
  ```

- 类成员方法

  ```java
  public int intValue()
  // 包装类型转为基本类型
  public static int parseInt(String s)
  // 字符串转数字
  public static String toString(int i)
  // 数字转字符串
  public static Integer valueOf(int i)
  public static Integer valueOf(Strng s)
  ```

- 进制转换

  ```java
  public static String toBinaryString(int i)
  // 十进制转二进制
  public static String toOctalString(int i)
  // 十进制转八进制
  public static String toHexString(int i)
  // 十进制转十六进制
  ```

- 十进制到其他进制

  ```java
  public static String toString(int i, int radix)
  ```

- 其他进制到十进制

  ```java
  public static int parseInt(String s, int radix)
  ```

  

## Character类

- 成员方法

  ```java
  public static boolean isUpperCase(char ch)
  // 判断字符是否是大写
  public static boolean isLowerCase(char ch)
  // 判断字符是否是小写
  public static boolean isDigit(char ch)
  // 判断字符是不是数字
  public static char toUpperCase(char ch)
  // 
  public static char toLowerCase(char ch)
  ```

  

## System类

```java
public static void gc()
// 内存清理
public static void exit(int status)
// 退出程序，习惯退出参数为0
public static long currentTimeMillis()
// 当前时间戳，1970-1-1起计时，单位：毫秒
```

## BigInteger类

- 描述

  - 可以让超过Integer范围内的数据进行运算

- 构造方法

  ```java
  public BigInteger(String val)
  ```

## BigDecemal类

- 描述

  - 解决小数运算精度问题

- 构造方法

  ```java
  public BigDecemal(String val)
  ```

## Date类

- 概述

  - 类Date表示特定的瞬间，精确到毫秒

- 构造方法

  ```
  public Date()
  public Date(long date)
  ```

- 成员方法

  ```java
  public long getTime()
  public void setTime(long time)
  ```

  

## DateFormat类

- 概述

  - DateFormat 是日期/时间格式化子类的抽象类，它以与语言无关的方式格式化并解析日期或时间
  - 是抽象类，所以使用其子类SimpleDateFormat

- SimpleDateFormat构造方法

  ```java
  public SimpleDateFormat()
  public SimpleDateFormat(String pattern)
  ```

  

- 成员方法

  ```java
  public final String format(Date date)
  // 日期转字符串
  DateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
  Date date = new Date();
  String strdate = df.format(date);
  System.out.println(strdate);
  public Date parse(String source)
  ----------------------------------------------------------------
  // 字符串转日期
  Scanner sc = new Scanner(System.in);
  DateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
  System.out.println("输入日期：");
  String strdate = sc.nextLine();
  Date date = df.parse(strdate);
  System.out.println(date);
  ```

  

## Calender类

- 概述

  - Calendar类是一个抽象类，它为指定瞬间与一组诸如YEAR、MONTH、HOUR等日历字段之前的转换提供了一些方法，并为操作日历字段提供了一些方法

- 成员方法

  ```java
  public static Calender getInstance()
  public int get(int field)
  // 获取日历中的指定部分
  public void add(int field, int amount)
  // 日期加减运算
  public final void set(int year, int month, int date)
  // 设置日日为指定的日期
  ```



## 异常

- 概述

  - 异常就是java在运行过程中出现错误
  - 我们常见异常： 角标越界异常、空指针异常

- 常见错误

  - 编译错误： 语法错误，编译器无法通过.class文件都没有
  - 逻辑错误： 编译通过，正常运行，结果和预想不一致
  - 异常： 程序运行时出错，有些宜昌市无法避免的，出现异常，程序应该能正常继续运行

- 异常结构

  - Throwable

    - Error： 严重的系统级错误，层序员不管

    - Exception： 程序员处理

      - RuntimeException及其子类 

        运行时异常： 编译器不会强制检查 - 非受查异常

      - 非RuntimeException及其子类 

        编译时异常： 编译会检查异常是否处理，没有处理编译报错- 受查异常

- 异常处理

  一个try可以跟

  ```jjava
  try{
  	// 可能发生异常的代码
  }catch (Exception e){  
  	// 异常发生后的处理
  }finally{
  	// 最后要做的事情
  }
  ```
  
  throw : 抛出异常：我的代码不处理异常，调用者来处理
  
- 异常体系

  - Throwable
    - Error
    - Exception
      - RuntimeException及其子类：非受查异常- 编译器不检查
      - 受查异常 - 编译器强制检查

- throws和throw区别

  - throws
    1. 用在方法声明后面，跟的是异常类名
    2. 可以跟多个异常类名，用逗号隔开
    3. 表示抛出异常，由该方法的调用者来处理
    4. throws表示出现的异常的一种可能性，并不一定会发生这些异常
  - throw
    	1. 用在方法体内，跟的是异常对象名
     	2. 只能抛出一个异常对象名
     	3. 表示抛出异常，有方法体内的语句处理
     	4. throw则是抛出了异常，执行throw则一定抛出了某种异常

 - 异常注意事项

    - 子类重写父类的方法时，子类的方法必须抛出相同的异常或父类异常的子类
    - 如果父类抛出了多个异常，子类重写父类时，只能抛出相同的异常或者是他的子集，子类不能抛出父类没有的异常
    - 如果被重写的方法没有异常抛出，那么子类的方法绝对不可以抛出异常，如果子类的方法内有异常发生，那么子类只能try，不能throws。

## Throwable类

```java
getMessage()
// 获取异常信息，返回字符串
toString()
// 获取异常类名和异常信息，返回字符串
printStackTrace()
// 获取异常类名和异常信息，以及异常出现在程序中的位置。返回值void
```





# 集合

代替数组

- 集合和数组的区别
  - 数组虽然也可以存储对象，但是长度是固定的，集合的长度是可变的
  - 数组中可以存储任何类型，集合只能存储对象
- 集合的特点
  - 集合只用于存储对象，集合长度是可变的，集合可以存储不同类型的对象
  - 如果要存储基本类型必须使用包装类（自动装箱）
  - 非泛型集合：集合中可以存储任意类型的数据
  - 泛型集合：定义集合时，必须规定集合中的元素类型

- 集合框架
  - Collection
    - List
      - ArraryList（重点）
      - LinkedList
    - Set
      - HashSet（重点）
      - TreeSet
  - Map
    - HashMap（重点）
    - TreMap

## Collection类

有些可重复，有些不可重复，有些有序，有些无序

- 接口成员方法

  ```java
  boolean add(E e)
  // 添加元素
  boolean remove(Object o)
  // 删除元素
  void clear()
  // 清空元素
  boolean contains(Objest o)
  // 集合是否包含某个元素
  boolean isEmpty()
  // 集合实都为空
  int size()
  // 获取集合中元素的个数
  Objest[] toArray()
  // 把集合转成数组，可以实现集合的遍历
  Iterator iterator()
  // 迭代器，集合的专用遍历方式
  ```


- 泛型集合

  - 数组：数据类型[]	数组名

  - 泛型集合：

    ```java
    Collection<类型> 集合对象 = new ArrayList<类型>()
    ```

- 泛型类 ： 泛型集合

- 泛型方法

- 泛型接口

## List接口

list的底层就是数组，提供了针对下标操作的方法

- 概述

  - 有序的collection（也称为序列）。此接口的用户可以对列表中的每一个元素的插入进行精确的控制。用户可以根据元素的整数索引（在列表中的位置）访问元素，并搜索列表的元素

  - 与set不同，列表通常允许重复的元素

- 案例

  - 储存字符串并遍历
  - 储存自定义对象并遍历

- 接口成员方法

  ```
  void add(int index, E element)
  // 添加元素到指定下标
  E remove(int index)
  // 删除指定下标元素
  E get(int index)
  // 获取指定下标的元素
  E set(int index, E element)
  // 修改指定下标的元素
  ListIterator listIterator()
  // 遍历元素 
  ```

- 父子关系
  - List
    - ArrayList
    - Vector
    - LinkedList
  - Set
    - HashSet
    - LinkedHashSet
    - TreeSet

## ArrayList类

- 概述
  - 底层数据结构时数组，查询快，增删慢
  - 线程不安全，效率高
- 案例
  - 存储字符串并遍历
  - 存储自定义对象并遍历

## Set接口



 ## File类

- 概述

  文件和目录路径的抽象表示形式

- 构造方法

  ```
  public File(String pathname)
  public File(String parent, String child)
  public File(File parent, String child)
  ```

- 创建功能

  ```java
  public boolean createNewFile()
  // 新建文件
  public boolean mkdir()
  // 创建目录
  public boolean mkdirs()
  // 创建多层目录 
  ```

- 删除功能

  ```java
  public boolean delete()
  ```

- 重命名功能

  ```java
  public boolean renameTo(File dest)
  ```

- 判断功能

  ```java
  public boolean isDirectory()
  // 判断是不是文件夹
  public boolean isFile()
  // 判断是不是文件
  public boolean exists()
  // 判断文件存不存在
  public boolean canRead()
  public boolean canWirte()
  public boolean isHidden()
  // 判断文件是否隐藏
  ```

- 基本获取功能

  ```java
  public String getAbsolutePath()
  // 获取完整文件路径
  public String getPath()
  // 获取路径名称的字符串
  public String getName()
  // 获取文件名字
  public long length()
  // 获取里面文字的长度
  public long lastModified()
  // 获取文件最后修改时间 
  ```

- 高级获取功能

  ```java
  public String[] list()
  public File[] listFiles()
  ```

  

## 递归

- 概述

  方法定义中调用方法本身的现象

- 注意事项

  1. 要有出口否则就是死递归
  2. 次数不能太多，否则就会内存溢出
  3. 构造方法不能递归使用

- 

## LinkedList类

LinkedList底层是链表，没有下标，但是用了算法模拟数组操作。

- 概述

  - 底层数据结构是链表，查询慢，增删快
  - 线程不安全，效率高

- 特有功能

  ```java
  public void addFirst(E e)及addLast(E e)
  // 添加第一个/最后一个
  public E getFirst()及getLast()
  // 过去第一个/最后一个
  public EremoveFirst()及public EremoveLast()
  // 移除第一个/最后一个
  ```

- 案例

  - 存储字符串 并遍历
  - 存储自定义对象并遍历

## Set接口

- 概述

  一个不包含重复元素的collection.

- 案例

  - 存储字符串并遍历
  - 寻出自定义对象并遍历



## HashSet类

- 概述

  无序不重复

- HashSet如何保证元素唯一性
  - 底层数据结构是哈希表（元素是链表的数据结构）
  - 添加功能底层依赖两个方法：
    - int hashCode()
    - boolean equals(Object obj)

## Map接口

- 概述
  - 将键映射到值的对象
  - 一个映射不能包含重复的键
  - 每个键最多只能映射到一个值
- Map接口和collection接口的区别
  - Map是双列的，Collection是单列的
  - Map的键唯一，Collection的子体系Set是唯一的

- 成员方法

  ```java
  V put(K key,V value)
  // 添加元素
  V remove(Object key)
  // 移除元素
  void clear()
  // 清空元素
  boolean containsKey(Object key)
  // 判断键有没有
  boolean containsValue(Object value)
  // 判断值有没有
  boolean isEmpty()
  // 判断是否为空
  int size()
  // 返回map长度
  V get(Object key)
  // 根据键获取值
  Set<K> KeySet()
  // 获取所有键的集合Set
  Collection<V> values()
  // 获取所有值的集合Collection
  Set<Map.Entry<K,V>> entrySet()
  // 获取键和值的集合
  ```

  

## Collection类

- 概述

  - 针对集合操作的工具类

- 成员方法

  ```java
  public static <T> void sort(List<T> list)
  // 排序
  public static <T> int binarySearch(List<?> list, T key)
  // 二分查找
  public static <T> T max(Collection<?> coll)
  // 最大
  public static void reverse(List<? list>)
  // 反转
  ```

  

## IO流

- 概述
  - IO流用来处理设备之间的数据传输
    - 上传文件和下载文件
  - Java对数据的操作是通过流的方式
  - Java用于操作流的对象在IO包中

- 分类

  - 按照数据流向
    - 输入流 读入数据
    - 输出流 写出数据
  - 按照数据类型
    - 字节流 - 操作中文字符方便。
    - 字符流 - 通用的，任何文件都可以操作。
    - 什么情况下使用那种流呢？
      - 如果数据所在的文件能通过win自带记事本打开，并读懂里面的内容，就用字符流
      - 其他使用字节流

- 字节流写数据

  **OutputStream**

  ```java
  // FileOutputStream()类
  // 构造方法
  FileOutputStream(File file)
  FileOutputStream(String name)
  ```

- 字节流写数据的方法

  ```java
  public void write(int b)
  // 写入字符编码
  public void write(byte[] b)
  public void write(byte[] b, int off, int len)
  ```

- 字节流读取数据

  **InputStream**

  ```java
  // FileInputStream类
  // 构造方法
  FileInputStream(File file)
  FileInputStream(String name)
  // 成员方法
  public int read()
  public int read(byte[] b)
  ```

- 字节缓冲流

  - 字节流一次写入一个数组的速度明显比一次读写一个字节的速度要快很多，这是加入了数组这样的缓冲区效果，java本身在设计的时候，也考虑到了这样的 设计思想，所以提供了字节缓冲区流。

  - 字节流缓存输入流

    ```java
    BufferedOutputStream()
    ```

  - 字节缓冲输入流

    ```java
    BufferedInputStream()
    ```

## OutputStreamWriter

字符输出流

```java
public OutputStreamWriter(OutputStream out)
public OutputStreamWriter(OutputStream out, String charsetName)
```



## InputStreamWriter

字符输入流

```java
public InputStreamWriter(OutputStream out)
public InputStreamWriter(OutputStream out, String charsetName)
```



## 序列化

- 序列化

  将对象存储到存储媒介（文件）

  ```java
  ObjectOutputStream
  ```

- 反序列化

  将储存介质中的数据还原成对象

  ```java
  ObjectInputStream
  ```

- transient

  指定序列化时，不需要存储属性

## Properties集合

- Properties 作为Map集合使用

- 特殊功能

  ```java
  public Object setProperty(String key, String value)
  public String setProperty(String key)
  public Set<String> stringPropertyNames()
  ```

- Properties和IO流结合使用

  ```java
  public void load(Reader reader)
  public void store(Writer weiter,String comments)
  ```

  