---
title: MongoDB基础
date: 2019-06-23 18:31:52
tags:
---

## 简介

MongoDB是2009年问世的一个面向文档的数据库管理系统，由C++语言编写，旨在为Web应用提供可扩展的高性能数据存储解决方案。虽然在划分类别的时候后，MongoDB被认为是NoSQL的产品，但是它更像一个介于关系数据库和非关系数据库之间的产品，在非关系数据库中它功能最丰富，最像关系数据库。

MongoDB将数据存储为一个文档，一个文档由一系列的“键值对”组成，其文档类似于JSON对象，但是MongoDB对JSON进行了二进制处理（能够更快的定位key和value），因此其文档的存储格式称为BSON。关于JSON和BSON的差别大家可以看看MongoDB官方网站的文章[《JSON and BSON》](https://www.mongodb.com/json-and-bson)。

目前，MongoDB已经提供了对Windows、MacOS、Linux、Solaris等多个平台的支持，而且也提供了多种开发语言的驱动程序，Python当然是其中之一。

## 基本概念

**在MongoDB中，数据库和集合都不需要手动创建，当我们创建文档时，如果文档所在的集合或数据库不存在，会自动创建数据库和集合**
- 数据库（database）
- 集合（collection）
- 文档（document）

## 基本指令
```js
show dbs OR show databases	# 显示当前所有数据库
use <database>			# 进入指定数据库
db 				# 显示当前所处数据库
show collections		# 显示数据库中的集合
```
## 数据库CRUD的查询 
```js
$or       	逻辑或
$and     	逻辑与
$not      	逻辑非
$nor      	逻辑or的取反
$exists   	存在逻辑
$type     	查询键的数据类型
$push		操作符添加指定的值到数组中
$ne		一个值不在数组里时就把它加进去，避免重复数据 
$set 		可以用来修改文档中指定属性
$unset 		可以删除文档中的制定属性
$addToSet	往数组里面加入数据，如果数组里已经存在，则不会加入
$pop		删除数组元素，只能从头部或尾部删除一个元素 
$pull		删除数组元素，将所有匹配的元素删除
$gt		查找大于
$gte		查找大于等于
$lt		查找小于
$inc		自增
{$gt:value，$lt:value}	查找区间

```
## insert()
```js
db.<collection>.insert(doc)		# 在<collection>中插入一个文档
db.collection.insertOne(doc)		# 插入一个文档
db.collection.insertMany(doc)		# 插入多个文档
```
## find()
```js
db.<collection>.find(doc)			# 查询当前集合中所有文档,返回一个数组
db.<collection>.find({'doc.doc':'值'})		# 查询当前集合中文档中的文档值
db.<collection>.findOne(doc)			# 查询一个，返回文档
db.<collection>.find(doc).count()		# 查询符合条件的是几个文档
db.<collection>.find(doc).limit(10)		# 查找前十的数据
db.<collection>.find(doc).skip(10).limit(10)	# 查找11条到20条的数据
db.<collection>.find($or:[条件，条件])		# 查找11条到20条的数据
```
## update()
```js
update() 默认情况使用新对象替换旧对象/默认只会修改一个
db.<collection>.update({查询条件}，{新对象})				# 替换一个文档
db.<collection>.update({查询条件}，{$set:{属性}})			# 修改一个文档
db.<collection>.update({查询条件}，{$unset:{属性}})			# 删除一个文档
db.<collection>.update({查询条件}，{$push/$addToSet:{属性}})		# 像数组中添加一个新元素
db.<collection>.updateMany() OR db.<collection>.update({multi:true})	# 修改多个
db.<collection>.repleceOne()						# 替换多个
```
## remove()
```js
remove() 默认删除多个/必须传参
remove({}) 清空集合
db.<collection>.remove(属性)		# 删除符合条件所有文档
db.<collection>.remove(属性,true)	# 删除一个文档
db.<collection>.drop()			# 删除集合
db.dropDatabase()			# 删库跑路
```
## 插入多数据
```js
for(var i=1; i<=100; i++){db.<collection>.insert(doc:i)}	# 循环插入100条数据
-------------------------------
var arr = [];
for(var i=1; i<=100; i++){arr.push({doc:i});}
db.<collection>.insert(arr)					# 快速插入100条数据
```

#### 在Python程序中操作MongoDB

可以通过pip安装pymongo来实现对MongoDB的操作。

```python
pip3 install pymongo
python3
>>> from pymongo import MongoClient
>>> client = MongoClient('mongodb://127.0.0.1:27017') 
>>> db = client.school
>>> for student in db.students.find():
...     print('学号:', student['stuid'])
...     print('姓名:', student['name'])
...     print('电话:', student['tel'])
... 
学号: 1001.0
姓名: 骆昊
电话: 13566778899
学号: 1002.0
姓名: 王大锤
电话: 13012345678
学号: 1003.0
姓名: 白元芳
电话: 13022223333
>>> db.students.find().count()
3
>>> db.students.remove()
{'n': 3, 'ok': 1.0}
>>> db.students.find().count()
0
>>> coll = db.students
>>> from pymongo import ASCENDING
>>> coll.create_index([('name', ASCENDING)], unique=True)
'name_1'
>>> coll.insert_one({'stuid': int(1001), 'name': '骆昊', 'gender': True})
<pymongo.results.InsertOneResult object at 0x1050cc6c8>
>>> coll.insert_many([{'stuid': int(1002), 'name': '王大锤', 'gender': False}, {'stuid': int(1003), 'name': '白元芳', 'gender': True}])
<pymongo.results.InsertManyResult object at 0x1050cc8c8>
>>> for student in coll.find({'gender': True}):
...     print('学号:', student['stuid'])
...     print('姓名:', student['name'])
...     print('性别:', '男' if student['gender'] else '女')
... 
学号: 1001
姓名: 骆昊
性别: 男
学号: 1003
姓名: 白元芳
性别: 男
>>> 
```