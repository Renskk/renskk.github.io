---
title: python魔法函数
date: 2019-09-3 18:31:52
tags:
---

## 简介

什么是魔法方法呢？它们在面向对象的Python的处处皆是。它们是一些可以让你对类添加“魔法”的特殊方法。 它们经常是两个下划线包围来命名的（比如 __init__ ， __lt__）。

## 构造方法

- \__new__(cls,[...)

  \_\_new\__ 是对象实例化时第一个调用的方法，它只取下 cls 参数，并把其他参数传给 \__init__ 

- \__init__(self,[...])

  类的初始化方法。它获取任何传给构造器的参数（比如我们调用 x = SomeClass(10, ‘foo’) ， \__init__ 就会接到参数 10 和 ‘foo’ 。 \_\_init__在Python的类定义中用的最多。

- \__del__(self)

  \__new__ 和 \_\_init__ 是对象的构造器， \_\_del__ 是对象的销毁器。它并非实现了语句 del x (因此该语句不等同于 x.\_\_del\_\_())。而是定义了当对象被垃圾回收时的行为。 当对象需要在销毁时做一些处理的时候这个方法很有用，比如 socket对象、文件对象。但是需要注意的是，当Python解释器退出但对象仍然存活的时候， \_\_del__ 并不会 执行。 所以养成一个手工清理的好习惯是很重要的，比如及时关闭连接。

## 操作符

使用Python魔法方法的一个巨大优势就是可以构建一个拥有Python内置类型行为的对象。这意味着你可以避免使用非标准的、丑陋的方式来表达简单的操作。

### 比较操作符

Python包含了一系列的魔法方法，用于实现对象之间直接比较，而不需要采用方法调用。同样也可以重载Python默认的比较方法，改变它们的行为。下面是这些方法的列表：

- \_\_cmp\_\_(self, other)

  \_\_cmp__ 是所有比较魔法方法中最基础的一个，它实际上定义了所有比较操作符的行为（<,==,!=,等等），但是它可能不能按照你需要的方式工作（例如，判断一个实例和另一个实例是否相等采用一套标准，而与判断一个实例是否大于另一实例采用另一套）。 \_\_cmp__ 应该在 self < other 时返回一个负整数，在 self == other时返回0，在 self > other 时返回正整数。最好只定义你所需要的比较形式，而不是一次定义全部。 如果你需要实现所有的比较形式，而且它们的判断标准类似，那么 \_\_cmp__ 是一个很好的方法，可以减少代码重复，让代码更简洁。

- \_\_eq__(self, other)

  定义等于操作符(==)的行为。

- \_\_ne__(self, other)

  定义不等操作符(!=)的行为。

- \_\_lt__(self, other)

  定义小于操作符(<)的行为。

- \_\_gt__(self, other)

  定义大于操作符(>)的行为。

- \_\_le__(self, other)

  定义小于等于操作符(<)的行为。

- \_\_ge__(self, other)

  定义大于等于操作符(>)的行为。

### 数值操作符

- \_\_pos__(self)

  实现取正操作，例如 +some_object。

- \_\_neg__(self)

  实现取负操作，例如 -some_object。

- \_\_abs__(self)

  实现内建绝对值函数 abs() 操作。

- \_\_invert__(self)

  实现取反操作符 ~。

- \_\_round__(self， n)

  实现内建函数 round() ，n 是近似小数点的位数。

- \_\_floor__(self)

  实现 math.floor() 函数，即向下取整。

- \_\_ceil__(self)

  实现 math.ceil() 函数，即向上取整。

- \_\_trunc__(self)

  实现 math.trunc() 函数，即距离零最近的整数。

### 算数操作符

- \_\_add__(self, other)

  实现加法操作。

- \_\_sub__(self, other)

  实现减法操作。

- \_\_mul__(self, other)

  实现乘法操作。

- \_\_floordiv__(self, other)

  实现使用 // 操作符的整数除法。

- \_\_div__(self, other)

  实现使用 / 操作符的除法。

- \_\_truediv__(self, other)

  实现 _true_ 除法，这个函数只有使用 from __future__ import division 时才有作用。

- \_\_mod__(self, other)

  实现 % 取余操作。

- \_\_divmod__(self, other)

  实现 divmod 内建函数。

- \_\_pow__

  实现 ** 操作符。

- \_\_lshift__(self, other)

  实现左移位运算符 << 。

- \_\_rshift__(self, other)

  实现右移位运算符 >> 。

- \_\_and__(self, other)

  实现按位与运算符 & 。

- \_\_or__(self, other)

  实现按位或运算符 | 。

- \_\_xor__(self, other)

  实现按位异或运算符 ^ 。

### 反射算数运算符

- \_\_radd__(self, other)

  实现反射加法操作。

- \_\_rsub__(self, other)

  实现反射减法操作。

- \_\_rmul__(self, other)

  实现反射乘法操作。

- \_\_rfloordiv__(self, other)

  实现使用 // 操作符的整数反射除法。

- \_\_rdiv__(self, other)

  实现使用 / 操作符的反射除法。

- \_\_rtruediv__(self, other)

  实现 _true_ 反射除法，这个函数只有使用 from \__future__ import division时才有作用。

- \_\_rmod__(self, other)

  实现 % 反射取余操作符。

- \_\_rdivmod__(self, other)

  实现调用 divmod(other, self) 时 divmod 内建函数的操作。

- \_\_rpow__

  实现 ** 反射操作符。

- \_\_rlshift__(self, other)

  实现反射左移位运算符 << 的作用。

- \_\_rshift__(self, other)

  实现反射右移位运算符 >> 的作用。

- \_\_rand__(self, other)

  实现反射按位与运算符 & 。

- \_\_ror__(self, other)

  实现反射按位或运算符 | 。

- \_\_rxor__(self, other)

  实现反射按位异或运算符 ^ 。

### 增强赋值运算法

**a += b \__iadd__ 也许会返回 a + b ，这个结果会被赋给 a**

```
x = 5
x += 1 # 也就是 x = x + 1
```

- \_\_iadd__(self, other)

  实现加法赋值操作。

- \_\_isub__(self, other)

  实现减法赋值操作。

- \_\_imul__(self, other)

  实现乘法赋值操作。

- \_\_ifloordiv__(self, other)

  实现使用 //= 操作符的整数除法赋值操作。

- \_\_idiv__(self, other)

  实现使用 /= 操作符的除法赋值操作。

- \_\_itruediv__(self, other)

  实现 _true_ 除法赋值操作，这个函数只有使用 from \__future__ import division 时才有作用。

- \_\_imod__(self, other)

  实现 %= 取余赋值操作。

- \_\_ipow__

  实现 **= 操作。

- \_\_ilshift__(self, other)

  实现左移位赋值运算符 <<= 。

- \_\_irshift__(self, other)

  实现右移位赋值运算符 >>= 。

- \_\_iand__(self, other)

  实现按位与运算符 &= 。

- \_\_ior__(self, other)

  实现按位或赋值运算符 | 。

- \_\_ixor__(self, other)

  实现按位异或赋值运算符 ^= 。

### 类型转换操作符

- \_\_int__(self)

  实现到int的类型转换。

- \_\_long__(self)

  实现到long的类型转换。

- \_\_float__(self)

  实现到float的类型转换。

- \_\_complex__(self)

  实现到complex的类型转换。

- \_\_oct__(self)

  实现到八进制数的类型转换。

- \_\_hex__(self)

  实现到十六进制数的类型转换。

- \_\_index__(self)

  实现当对象用于切片表达式时到一个整数的类型转换。如果你定义了一个可能会用于切片操作的数值类型，你应该定义 \__index__。

- \_\_trunc__(self)

  当调用 math.trunc(self) 时调用该方法， \__trunc__ 应该返回 self 截取到一个整数类型（通常是long类型）的值。

- \_\_coerce__(self)

  该方法用于实现混合模式算数运算，如果不能进行类型转换，\__coerce__ 应该返回 None 。反之，它应该返回一个二元组 self 和 other ，这两者均已被转换成相同的类型。

## 类的表示

- \_\_str__(self)

  定义对类的实例调用 str() 时的行为。

- \_\_repr__(self)

  定义对类的实例调用 repr() 时的行为。 str() 和 repr() 最主要的差别在于“目标用户”。 repr() 的作用是产生机器可读的输出（大部分情况下，其输出可以作为有效的Python代码），而 str() 则产生人类可读的输出。

- \_\_format__(self)

  定义当类的实例用于新式字符串格式化时的行为，例如， “Hello, 0:abc!”.format(a) 会导致调用 a.\__format__(“abc”) 。当定义你自己的数值类型或字符串类型时，你可能想提供某些特殊的格式化选项，这种情况下这个魔法方法会非常有用。

- \_\_hash__(self)

  定义对类的实例调用 hash() 时的行为。它必须返回一个整数，其结果会被用于字典中键的快速比较。同时注意一点，实现这个魔法方法通常也需要实现 \__eq__ ，并且遵守如下的规则： a == b 意味着 hash(a) == hash(b)。

- \_\_nonzero__(self)

  定义对类的实例调用 bool() 时的行为，根据你自己对类的设计，针对不同的实例，这个魔法方法应该相应地返回True或False。

- \_\_dir__(self)

  定义对类的实例调用 dir() 时的行为，这个方法应该向调用者返回一个属性列表。一般来说，没必要自己实现 \__dir__ 。但是如果你重定义了 \__getattr__ 或者 \__getattribute__ （下个部分会介绍），乃至使用动态生成的属性，以实现类的交互式使用，那么这个魔法方法是必不可少的。