---
title: Java多线程	
date: 2019-08-11 12:21:02
tags:
---

# 多线程

## 多线程概述

- 进程：
  - 正在允许中的程序，是系统进行资源分配和调用的独立单位
  - 每一个进程都有它自己的内存空间和系统资源
- 线程：
  - 是进程中的单个顺序控制流，是一条执行路径
  - 一个进程如果只有一条执行路径，则称为单线程程序
  - 一个进程如果有多条执行路径，则称为多线程程序
- 并行和并发
  - 并行是逻辑上同时发生，指在某一个时间内同时运行多个程序
  - 并发是物理上同时发生，只在某一个时间点同时运行多个程序

## 开启多线程 - 方法一

1. 自定义类集成Thread类
2. 重写run()
3. 创建对象
4. 启动线程

### 获取和设置多线程名称

- Thread类的基本获取和设置方式

  ```java
  public final String getNmae()
  public final void setName(String name)
  // 通过构建方法也可以给线程起名字
  public static Thread currentThread()
  ```


### 线程调度

- 线程调度的两种调度模式

  - 分时调度模型，所有线程轮流使用CPU的使用权，平均分配给每个线程占CPU的时间片
  - 抢占式调度模型，有限让优先级高的线程使用CPU，如果线程的优先级相同，那么会随机选择一个，优先级高的线程获取的CPU时间片相对多一些

- java使用的是抢占式调度模型

- 设置和获取线程优先级

  ```java
  public final int getPriority()
  // 获取当前线程优先级
  public final void setPriority(int newPriority)
  // 设置线程优先级 1-10
  ```

  

### 线程控制

- 线程休眠

  ```java
  public static void sleep(long millis)
  ```

- 线程加入

  ```java
  public final void join()
  ```

- 线程礼让

  ```java
  public static void yield()
  ```

- 后台线程 - 守护线程

  ```java
  public final void setDaemon(boolean on)
  ```

- 中断线程

  ```java
  public final void stop()
  // 过时方法 - 不建议使用：不能捕获异常
  public void interrupt()
  // 可以捕获异常
  ```

  

## 开启多线程 - 方法二

1. 创建myRunnable类实现Runnable接口
2. Thread类的构造方法传入myRunnable类
3. 调用Thread的start()方法来启动线程

## 解决线程安全的思想

- 首先想为什么出现问题？

  - 是否是多线程环境
  - 是否有共享数据
  - 是否有多条语言操作共享数据

- 如何解决多线程安全问题？

  加同步锁

  - 基本思想：让程序处于没有安全问题的环境
  - 怎么实现？
    - 把多个语句操作共享数据的代码给锁起来，让任意时刻只能有一个线程秩序即可

- 同步锁是谁？
  - 实例方法 : this
  - 静态方法 : 类.class - 当前类的字节码对象

## 死锁问题

- 同步弊端
  - 效率低
  - 如果出现同步嵌套，就容易产生死锁问题
- 死锁问题及其代码
  - 是指产生两个或者两个以上的线程在执行的过程中，因争夺资源产生的一种互相等待现象
  - 同步代码块的嵌套案例

## 线程通信

针对统一个资源的操作有不同的线程

- 生产者和消费者问题
  - 获取学生对象
    - 生产者：创建学生对象线程
    - 消费者：获取学生对象

**生产者和消费者模型**

- 创建Student类

  ```java
  public class Student {
      
      private String name;
      private int age;
      boolean flag;
  
      public void setName(String name) {
          this.name = name;
      }
  
      void setAge(int age) {
          this.age = age;
      }
  
      @Override
      public String toString() {
          return "Student{" +
                  "name='" + name + '\'' +
                  ", age=" + age +
                  '}';
      }
  }
  
  ```

- 创建SetStudent生产者类

  ```java
  public class SetStudent implements Runnable {
  
      private final Student s;
      private int count = 1;
      SetStudent(Student s) {
          this.s = s;
      }
  
      @Override
      public void run() {
          while (true){
              synchronized (s){
                  if (s.flag){
                      try {
                          s.wait(); // 等待，归还锁，下次被唤醒，就从此处开始执行
                      } catch (InterruptedException e) {
                          e.printStackTrace();
                      }
                  }
                  if (count %2 == 0){
                      // 学生类赋值
                      s.setName("tim");
                      s.setAge(11);
                  }else {
                      s.setName("tom");
                      s.setAge(12);
                  }
                  count++;
                  s.flag = true;
                  s.notify(); // 唤醒消费者
              }
          }
      }
  }
  ```

- 创建GetStudent消费者类

  ```java
  public class GetStudent implements Runnable {
  
      private final Student s;
      GetStudent(Student s) {
          this.s = s;
      }
  
      @Override
      public void run() {
          while (true){
              synchronized (s){
                  if (!s.flag){
                      try {
                          s.wait(); // 等待，归还锁，下次被唤醒，就从此处开始执行
                      } catch (InterruptedException e) {
                          e.printStackTrace();
                      }
                  }
                  System.out.println(s);
                  s.flag = false;
                  s.notify(); // 唤醒生产者
              }
          }
      }
  }
  ```

- 创建测试类

  ```java
  public class StudentTest {
      public static void main(String[] args) {
          Student s = new Student();
          SetStudent s1 = new SetStudent(s);
          GetStudent s2 = new GetStudent(s);
          Thread t1 = new Thread(s1);
          Thread t2 = new Thread(s2);
          t1.start();
          t2.start();
      }
  }
  ```

## 单例模式 - 多线程

- 懒汉式

  - 优点： 不会占用过多的系统资源

  - 缺点： 第一次访问慢，第一次惩罚，延迟加载

    ```java
    class MySingletonLazy {
    
        // 懒汉式 - 不会创建一个对象，而是在调用的时候再创建
        private static MySingletonLazy mySingleton;
    
        // 懒汉式需要加锁来保证线程安全，相比饿汉式执行效率低
        static synchronized MySingletonLazy createInstance(){
            if (mySingleton == null){
                mySingleton = new MySingletonLazy();
            }
            return mySingleton;
        }
    }
    ```

- 饿汉式

  - 优点： 第一次使用加载快

  - 缺点：会占用过多资源

    ```java
    class MySingleton {
    
        // 饿汉式 - 上来就创建好对象等待调用，以空间换时间
        private static MySingleton mySingleton= new MySingleton();
        
        static MySingleton createMySingleton(){
            return mySingleton;
        }
    }
    ```

    

