---
title: centos修改时间为北京时间
date: 2019-9-27 12:27:34
tags:
---

1. 查看当前系统时间

   ```shll
   $ date
   ```

2. 删除本地时间并设置时区为上海

   ```shell
   $ rm -rf /etc/localtime
   $ ln -s /usr/share/zoneinfo/Asia/Shanghai /etc/localtime
   ```

3. 安装ntp

   ```shell
   $ yum install ntp
   ```

4. 启动ntpd服务

   ```shell
   $ service ntpd restart
   ```

5. 查看当前硬件时间，并使用hwclock -w命令从当前系统时间设置硬件时钟

   ```shell
   $ hwclock -w
   ```

   

