---
title: docker下使用Nginx
date: 2019-09-23 12:27:34
tags:
---

## docker中搜索可用镜像

```shell
$ docker search nginx
```

## 获取Nginx官方镜像

```shell
$ docker pull nginx
```

## vue项目打包

```shell
# 安装cnpm
$ npm install -g cnpm --registry=https://registry.npm.taobao.org
# 安装&打包项目
$ cnpm install
$ cnpm run build
```

## 使用Dockerfile构建Nginx环境

- 在项目根目录（dist所在目录）编写dockerfile文件

  ```shell
  $ vim Dockerfile
  ```

  内容如下

  ```shell
  FROM nginx
  COPY dist/ /usr/share/nginx/html/
  COPY default.conf /etc/nginx/conf.d/default.conf
  ```

- 在在项目根目录（dist所在目录）编写配置文件default.conf

  ```shell
  $ vim default.conf
  ```

  内容如下

  ```shell
  server {
      listen       80;
      server_name  localhost;
  
      #charset koi8-r;
      access_log  /var/log/nginx/host.access.log  main;
      error_log  /var/log/nginx/error.log  error;
  
      location / {
          root   /usr/share/nginx/html;
          index  index.html index.htm;
      }
      error_page   500 502 503 504  /50x.html;
      location = /50x.html {
          root   /usr/share/nginx/html;
     }
  }
  ```

- 使用docker build构建

  ```shell
  # 命令最后面有个点
  $ docker build -t testnginx .
  ```

## 执行test_nginx镜像

```shell
$ docker run -p 3000:80 -d --name test testnginx
```







