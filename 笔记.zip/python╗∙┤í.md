---
title: Python基础
date: 2018-04-09 18:31:52
tags:
---
## 列表
### index()
```python
>>> spam = ['hello', 'hi', 'howdy', 'heyas']
>>> spam.index('hello')
0
```
### 列表中添加值
```python
# append()
>>> spam = ['cat', 'dog', 'bat']
>>> spam.append('moose')
['cat', 'dog', 'bat', 'moose']
# insert()
>>> spam = ['cat', 'dog', 'bat']
>>> spam.insert(1,'chicken')
['cat', 'chicken', 'dog', 'bat']
```
### 列表中删除值
```python
>>> spam = ['cat', 'dog', 'bat']
>>> spam.remove('bat')
['cat', 'dog']
```
### 列表排序
```python
# sort()可以按数字顺序，字母顺序排序
>>> spam = [2,4,1,9]
>>> spam.sort()
[1,2,4,9]
# 制定reverse关键字参数为True，让sort()排倒序
>>> spam.sort(reverse=True)
[9,4,2,1]
```
- 浅拷贝
  - 浅拷贝只做最顶层的数据类型判断
  - 如果顶层是**可变**类型则创建新的内存空间
  - 如果顶层是**不可变**数据类型就是引用拷贝
- 深拷贝
  - 深拷贝做递归拷贝，可以递归拷贝所有的内部嵌套数据（可以理解为循环遍历做浅拷贝判断）
  - 深拷贝递归拷贝遇到**可变**类型则创建新的内存空间
  - 深拷贝递归拷贝遇到**不可变**数据类型就是拷贝的引用

### 列表复制

```python
# copy()浅度复制，deepcopy()深度复制
>>> import copy
>>> spam = ['a', 'b', 'c', 'd']
>>> cheese = copy.copy(spam)
>>> cheese[1] = 1
>>> spam
['a', 'b', 'c', 'd']
>>> cheese
['a', 1, 'c', 'd']
```
### 切片
```python
>>> L = ['Michael', 'Sarah', 'Tracy', 'Bob', 'Jack']
>>> L[0:3] OR L[:3]	 	# 取L列表的前三个元素
>>> L[1:3] 			# 从索引1开始取出两个元素
>>> L[-1] 			# 取倒数第一个元素
---------------------------------------
>>> L = list(rang(100))		# 创建一个0-99的数列
>>> L[:10] 			# 取出前十个数
>>> L[-10:] 			# 取出后十个数
```
### 字符列表互换
```python
>>> ls = [1, 2, 3]
>>> lstr = list(map(str, ls))	# 整数列表转化为字符串列表
>>> str = ','.join(ls)		# 列表转换字符串
--------------------------------------
>>> str = '1,2,3'
>>> ls = str.strip().split(',')		# 以逗号为分隔转为列表
```
## 去重

```python
# 列表去重
>>> a=[1,2,3,4,1,2,3,4]
>>> a=list(set(a))
[1,2,3,4]
# 嵌套列表去重
>>> b = [[1,2,3,4],[1,2,3,4],[1,2,3,4]]
>>> b = [list(t) for t in set(tuple(i) for i in b)]
[[1,2,3,4]]
```



## 获取列表值的次数

```python
>>> list = [1,3,8,9,15,12,15,3,3,9]
>>> a = {}                     #定义空字典
>>> for i in set(list):        #去重复的值，set
>>>     a[i] = list.count(i)   #去重后做计数，把数量和值写到字典a  
>>> print(a)
{1: 1, 3: 3, 8: 1, 9: 2, 12: 1, 15: 2}
```



### 补充

```python
>>> li = [[1],[2]][True]
[2]
>>> li = [[1],[2]][False]
[1]
>>> li = [[1],[2],[3]][True]
[2]
```

## 字典

### keys()
```python
>>> spam = {'color':'red', 'age':'12'}
>>> spam.keys()
dict_keys(['color', 'age'])
>>> list(spam.keys())
['color', 'age']
```
### values()
```python
>>> spam = {'color':'red', 'age':'12'}
>>> for i in spam.values():
    print(i)
red
12
```
### items()
```python
>>> spam = {'color':'red', 'age':'12'}
>>> for i, j in spam.items():
>>>     print('Key: ' + i + 'Value: ' + str(j))
Key: age Value: 12
Key: color Value: red
```
### get()
在访问一个键的值之前，检查该键是否存在字典中，这很麻烦。好在字典有一个get()方法，它有两个参数：要取得其值的键，以及如果该键不存在时，返回的备用值。
```python
>>> picnicItems = {'apples': 5, 'cups': 2}
>>> picnicItems.get('cups', 0 )
2
>>> picnicItems.get('eggs', 0 )
0
```
### setdefault()
方法提供了一种方式，在一行中完成这件事。传递给该方法的第一个参数，是要检查的键。第二个参数，如果改建不存在时要设置的值。如果该键确实存在，方法就会返回键的值。
```python
>>> spam = {'name': 'pooka', 'age': 5}
>>> spam.setdefault('color', 'black')
'black'
>>> spam.setdefault('color', 'while')
'black'
>>> spam
{'color': 'black', 'name': 'pooka', 'age': 5}
```
## 字符串
### upper()/lower()
upper()和lower()字符串方法返回一个新字符，其中原字符串的所有字母都被相应地转换为大写或小写。字符串中非非字母字符保持不变
```python
>>> spam = 'Hello world!'
>>> spam = spam.upper()
>>> spam
'HELLO WORLD!'
>>> spam = spam.lower()
>>> spam
'hello world!'
```
### isupper()/islower()
如果字符串至少有一个字母，并且所有字母都是大写或小写，isupper()和islower()方法就会相应地返回布尔值True.否则返回False
```python
>>> spam = 'Hello world!'
>>> spam.isupper()
False
>>> spam.islower()
False
```
|方法名|反参|解释|
|-|-|-|
|isalpha()|True|如果字符串只包含字母，并且非空|
|isalnum()|True|如果字符串只包含字母和数字，并且非空|
|isdecimal()|True|如果字符串只包含数字字符，并且非空|
|isspace()|True|如果字符串只包含空格、制表符和换行符，并且非空|
|istitle()|True|如果字符串仅包含以大写字母开头、后面都是小写字母的单词|

### startswith()/endswith()
startswith()和endswith()方法返回True,如果它们所调用的字符串以该方式传入的字符串开始或结束。否则，方法返回False
```python
>>> 'Hello world!'.startswith('Hello')
True
>>> 'Hello world!'.endswith('world!')
True
```
### join()/split()
```python
>>> ','.join(['cats', 'rats', 'bats'])
'cats, rats, bats'
>>> ' '.join(['I', 'am', 'a', 'cat'])
'I am a cat'
>>> 'ABC'.join(['I', 'am', 'a', 'cat'])
'IABCamABCaABCcat'
>>> 'I am a cat'.split()
['I', 'am', 'a', 'cat']
```
### rjust()/ljust()/center()
对齐文本
```python
>>> 'Hello'.rjust(10)
'          Hello'
>>> 'Hello'.rjust(20)
'                    Hello'
>>> 'Hello'.ljust(10)
'Hello          '
>>> 'Hello'.rjust(10, '*')
'**********Hello'
>>> 'Hello'.ljust(10, '*')
'Hello**********'
>>> 'Hello'.center(10)
'          Hello          '
>>> 'Hello'.center(10, '=')
'==========Hello=========='
```
### strip()/rstrip()/lstrip()
strip()字符串方法将返回一个首位没有空白符的字符，lstrip()和rstrip()方法将删除左边或右边的空白字符
```python
>>> spam = ' Hello world! '
>>> spam.strip()
'Hello world!'
>>> spam.lstrip()
'Hello world! '
>>> spam.rstrip()
' Hello world!'
```
### pyperclip
用pyperclip模块拷贝粘贴字符串

## isinstance()

isinstance() 函数来判断一个对象是否是一个已知的类型，类似 type()

isinstance() 与 type() 区别：

- type() 不会认为子类是一种父类类型，不考虑继承关系。
- isinstance() 会认为子类是一种父类类型，考虑继承关系。

如果要判断两个类型是否相同推荐使用 isinstance()

```python
>>>a = 2
>>> isinstance (a,int)
True
>>> isinstance (a,str)
False
>>> isinstance (a,(str,int,list))    # 是元组中的一个返回 True
True
```

## 问题

- python使用base64进行编码的时候，会使用byte格式，想要没有b''包裹的结果需要转换成字符串格式

  ```python
  base64_image = str(base64.b64encode(image.read()), 'utf-8')
  ```

  