---
title: Jenkins + Gitlab + 钉钉推送	
date: 2019-08-22 12:21:02
tags:
---



## 准备工作

1. 更新Git
2. 安装Maven
3. 安装JDK
4. 安装python3

## 安装jenkins

### 1、安装

```shell
wget https://pkg.jenkins.io/redhat/jenkins-2.176.2-1.1.noarch.rpm
rpm -ivh jenkins-2.176.2-1.1.noarch.rpm
```

### 2、配置

```shell
# 编辑jenkins配置文件
vim /etc/sysconfig/jenkins
# 更改端口 - 初始端口是8080与tomcat冲突
JENKINS_PORT="8088"
```

### 3、权限

修改用户

```shell
# 修改权限为root 避免以后的权限坑
vim /etc/sysconfig/jenkins
$JENKINS_USER="root"
```

修改目录权限

```shell
chown -R root:root /var/lib/jenkins
chown -R root:root /var/cache/jenkins
chown -R root:root /var/log/jenkins
```

重启jenkins

```shell
# 重启
service jenkins restart
# 查看jenkins是否已经改为root用户
ps -ef | grep jenkins
```

### 4、启动

```shell
systemctl start jenkins
# 访问jenkins地址
http://localhost:8088
```

按jenkins提示进行安装 - 插件选择安装推荐的插件

### 5、设置

#### （1）设置全局变量

1. 进入全局变量设置

   ![设置1](https://s2.ax1x.com/2019/08/23/mBzxkn.png)

2. 设置Maven

   ![设置2](https://s2.ax1x.com/2019/08/23/mBzzYq.png)

3. 设置JDK

   ![JDK设置](https://s2.ax1x.com/2019/08/23/mBzUL4.png)

4. 设置GIT

   ![GIT设置](https://s2.ax1x.com/2019/08/23/mBztQU.png)

5. 设置Maven

   ![Maven设置](https://s2.ax1x.com/2019/08/23/mBzsW6.png)

#### （2）设置安全设置

1. 进入安全设置

   ![进入安全设置](https://s2.ax1x.com/2019/08/23/mBzOmQ.png)

2. 根据下图进行设置

   ![安全设置](https://s2.ax1x.com/2019/08/23/mBzfwd.png)

#### （3）安装插件

1. [Python Plugin](http://wiki.jenkins-ci.org/display/JENKINS/Python+Plugin)
2. [SSH Slaves plugin](https://wiki.jenkins-ci.org/display/JENKINS/SSH+Slaves+plugin)
3. [Deploy to container Plugin](http://wiki.jenkins-ci.org/display/JENKINS/Deploy+Plugin)



## 创建项目

#### （1）准备工作 

1. 生成ssh key

   ```shell
   # 在jenkins服务器生成ssh -key
   ssh-keygen -t rsa
   ```

2. 获取ssh 公钥

   ![ssh公钥](https://s2.ax1x.com/2019/08/23/mBzcQO.png)

3. 在gitlab项目中添加ssh公钥

   ![gitlabSSH](https://s2.ax1x.com/2019/08/23/mBzDF1.png)

4. 获取ssh密钥

   ![ssh密钥](https://s2.ax1x.com/2019/08/23/mBzgyD.png)

5. 在jenkins中添加ssh密钥

   ![凭据1](https://s2.ax1x.com/2019/08/23/mBzXwj.png)

   ![凭据2](https://s2.ax1x.com/2019/08/23/mBzjTs.png)

   ![创建凭据](https://s2.ax1x.com/2019/08/23/mBzhTA.png)

	#### （2）新建

1. **新建Item**

2. 输入项目名称，选择自由项目

   ![创建项目](https://s2.ax1x.com/2019/08/23/mBzIYt.png)

3. 点击确认

   

#### （3）项目设置

1. **源码管理**

   Repository URL 为gitlab中clone地址

   Credentials 为添加的SSH

   ![git源码](https://s2.ax1x.com/2019/08/23/mBzww9.png)

2. **构建触发器**

   - 构建远程触发，输入身份令牌，拼写为红字网址

   ![构建触发器](https://s2.ax1x.com/2019/08/23/mBzb6S.png)

   - 利用gitlab webhook进行触发

     ![gtilabWebhook](https://s2.ax1x.com/2019/08/23/mBz0oR.png)

     ​	

   - gitlab添加webhook需要用管理员账号打开

     设置-网络-外部发送-允许来自钩子和服务的对本地网络的请求

3. 构建**

   - 调用maven,执行shell命令

   ![构建](https://s2.ax1x.com/2019/08/23/mBzofP.png)

   - Execute shell

     ```shell
     #!/bin/bash
     cd /home/test/
     echo "执行脚本"
     sh stop.sh
     sh replace.sh
     BUILD_ID=dontKillMe nohup /home/test/startup.sh &
     ```

     

   - stop.sh

     ```shell
     pid=`ps -ef | grep elk-1.0.jar | grep -v grep | awk '{print $2}'`
     if [ -n "$pid" ]
     then
        echo "kill -9 的pid:" $pid
        kill -9 $pid
     fi
     ```

     

   - replace.sh

     ```shell
     cp /home/test/dingTalkPush.py /var/lib/jenkins/workspace/test/
     ```

   - startup.sh

     ```shell
     echo "执行jar包"
     nohup java -jar /home/test/elk-1.0.jar >/dev/null 2>&1 &
     ```

4. 钉钉推送

   [钉钉开发文档](https://ding-doc.dingtalk.com/doc#/serverapi2/qf2nxq)

   - 添加Execute Python script

   ```python
   # coding:utf-8
   import os, json, sys, time
   
   sys.path.append('/usr/local/lib/python3.7/site-packages')
   import jenkins
   import requests
   
   reload(sys)
   sys.setdefaultencoding('utf8')
   
   
   def sendding(title, content):
       # 钉钉的webhook地址
       url = "https://oapi.dingtalk.com/robot/send?access_token={#填写钉钉token}"
   
       # 钉钉发送的消息
       pagrem = {
           "msgtype": "markdown",
           "markdown": {
               "title": title,
               "text": content,
           },
           # "at": {
           #    "atMobiles": [
           #         "156xxxx8827",
           #         "189xxxx8325"
           #     ],
           #     "isAtAll": false # @全体成员
           # }
       }
   
       # 钉钉传参的头部信息
       headers = {
           "charset": "utf-8",
           'Content-Type': 'application/json'
       }
   
       # 向钉钉推送请求
       requests.post(url, data=json.dumps(pagrem), headers=headers)
   
   
   def notification():
       # 获取git日志
       logStr = os.popen("git log").read()
       new_str = logStr.split('commit')[1].split('\n')
       puthCommit = ''
       for i in new_str:
           if 'Author' in i:
               # 获取提交者的名字
               pushName = i.split()[1]
           if 'Date' in i:
               # 获取提交者的时间
               pushTimes = i.split()
           if '    ' in i:
               puthCommit += i.strip()
   
       # 获取推送的月份
       mm = pushTimes[2]
   
       # 获取推送的日期
       dd = pushTimes[3]
   
       # 获取推送的时间
       hh = pushTimes[4]
   
       # 获取推送的年份
       yy = pushTimes[5]
   
       months = {'Jan': '1', 'Feb': '2', 'Mar': '3', 'Apr': '4', 'May': '5', 'Jun': '6', 'Jul': '7', 'Aug': '8',
                 'Sep': '9', 'Oct': '10', 'Nov': '11', 'Dec': '12'}
   
       # 时间字符串
       pushTime = "time ： " + yy + "-" + months[mm] + "-" + dd + "  " + hh
   
       # jenkins的请求
       server = jenkins.Jenkins('http://192.168.1.180:8081/', username='admin', password='123456')
   
       # 获取上次构建的项目序号
       build_number = server.get_job_info('WBS')['lastBuild']['number']
   
       # 获取Jenkins构建时的日志
       jenkinsLog = server.get_build_console_output('WBS', build_number)
       if jenkinsLog is "null":
           jenkinsLog = server.get_build_console_output('WBS', build_number - 1)
   
       time.sleep(10)
   
       # 产看docker正在运行的服务
       results = os.popen('docker ps -a')
   
       results = results.read()
       list = []
       print("*******  docker  *******")
       for line in results.splitlines()[:5]:
           print(line)
           list.append(line)
   
   
       if '8080' in list[1]:
           ruselt = '成功'
       else:
           ruselt = '失败'
           os.system('docker logs wbs')
           
       print(ruselt)
           
           
       # 打印上次构建的序号
       # print("BUILD_NUMBER："+ str(build_number))
       print('------------------------------------------------------------------------------')
   
       # 钉钉推送的消息title
       title = pushName + ' [WBS]第' + str(build_number) + '次部署'  + ruselt
   
       # 钉钉推送的消息内容
       content = "### " + title + "\n" + "> " + pushTime + "\n\n" + "> commit ： " + puthCommit + "\n\n" + "> [jenkins 控制台输出](http://192.168.1.180:8081/job/WBS/%s/console)\n" % build_number
   
       time.sleep(5)
       # 调用钉钉推送方法
       sendding(title,content)
   
   if __name__ == "__main__":
       notification()
   ```

5. 点击保存，完成项目配置







​		

