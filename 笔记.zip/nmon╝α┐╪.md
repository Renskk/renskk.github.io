---
title: nmon监控linux系统资源
date: 2018-10-29 18:31:52
tags:
---
## nmon简介
nmon是一个分析aix和linux性能的免费工具（其主要是ibm为自己的aix操作系统开发的，但是也可以应用在linux操作系统上）
nmon_analyser：是nmon的一个工具可以把nmon生成的报告转化成excel报表的形式供我们查看。两者的结合可以把各个硬件的监控信息生成形象化的分析报表图
下载地址：http://nmon.sourceforge.net/pmwiki.php?n=Site.Download
## 安装使用方法
1.用root用户登录Linux操作系统，建立目录：#mkdir /opt/nmon
2.切换路径：cd /opt/nmon
3.用命令rz将下载的nmon工具上传至Linux服务器 目录/opt/nmon下
4.修改tar包权限：#chmod +x nmon_linux_14i_newer_Linux_versions.tar.gz
5.解压文件：#tar -xzvf nmon_linux_14i_newer_Linux_versions.tar.gz
5.执行授权命令：#chmod +x nmon_linux_x86
6.更改名字 : # mv nmon_linux_x86 nmon
7.运行nmon命令: # ./nmon
8.敲c:CPU相关资源信息
9.敲m:memory相关资源信息
10.敲d:disk磁盘相关信息
11.敲n:network相关信息
12.创建一个存放结果的文件夹：mkdir /opt/nmon/log
13.监控系统资源：./nmon -f -N -m /opt/nmon/log/ -s 10 -c 60,每10秒采集一次数据，采集60次
14.使用命令sz，将Linux系统中的文件下载到Windows本地
15.解压nmon_analyser_v51_2.zip，打开nmon analyser v51_2.xlsm，启用宏，方可使用
16.点击Analyser nmon data,选择已经下载好的结果文件，自动生成报告。