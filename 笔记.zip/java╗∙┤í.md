---
title: Java基础	
date: 2019-06-12 12:21:02
tags:
---

# 八大基本数据类型

## 数据类型

| 基本数据类型           | 对应包装类          |
| ---------------------- | ------------------- |
| byte（字节型）         | java.lang.Byte      |
| short（短整型）        | java.lang.Short     |
| int（整型）            | java.lang.Integer   |
| long（长整型）         | java.lang.Long      |
| float（单精度浮点型）  | java.lang.Float     |
| double（双精度浮点型） | java.lang.Double    |
| boolean（布尔型）      | java.lang.Boolean   |
| char（字符型）         | java.lang.Character |

## 详细划分

整形：**byte、short、int、long**

浮点型：**float、double**

逻辑型：**Boolean** 

字符型：**char**

## 默认值

| 顺序  | **数据类型**       | 大/小  | 封装类        | **默认值**   | 可表示数据范围**                             |
| ----- | ------------------ | ------ | ------------- | ------------ | -------------------------------------------- |
| **1** | **Byte**(位)       | **8**  | **Byte**      | **0**        | **-128~127**                                 |
| **2** | **short**(短整数)  | **16** | **Short**     | **0**        | **-32768~32767**                             |
| **3** | **int**(整数)      | **32** | **Interger**  | **0**        | **-2147483648~2147483647**                   |
| **4** | **long**(长整数)   | **64** | **Long**      | **0L**       | **-9223372036854775808~9223372036854775807** |
| **5** | **float**(单精度)  | **32** | **Float**     | **0**.**0F** | **1.4E-45~3.4028235E38**                     |
| **6** | **double**(双精度) | **64** | **Double**    | **0**.**0D** | **4.9E-324~1.7976931348623157E308**          |
| **7** | **char**(字符)     | **16** | **character** | **空**       | **0~65535**                                  |
| **8** | **boolean**        | **8**  | **boolean**   | **flase**    | **True 或 false**                            |

**当一个变量被** **final** **修饰后** **该变量只有一次赋值机会**

# 算数操作符

**基本：**+**、** **- 、\*、 /、 %、 ++、 --**

# Scanner 

```java
Import java.util.Scanner;		// 导包

Scanner s = new Scanner(System.in);   	 //获取一个输入的值
Int a = s.nextInt();         			 //输入的值赋值给a
String str = s.nexLine();    
float a = s.nextFloat();
```

# DecimalFormat

使用DecimalFormat将数字进行格式化

```java
//取一位整数
System.out.println(new ecimalFormat("0").format(pi));		//3

//取一位整数和两位小数
System.out.println(new DecimalFormat("0.00").format(pi));	//3.14

//取两位整数和三位小数，整数不足部分以0填补。
System.out.println(new DecimalFormat("00.000").format(pi));	//03.142

//取所有整数部分
System.out.println(new DecimalFormat("#").format(pi));	//3

//以百分比方式计数，并取两位小数
System.out.println(new DecimalFormat("#.##%").format(pi));	//314.16%
longc=299792458;	//光速

//显示为科学计数法，并取五位小数
System.out.println(new DecimalFormat("#.#####E0").format(c));	//2.99792E8

//显示为两位整数的科学计数法，并取四位小数
System.out.println(new DecimalFormat("00.####E0").format(c));	//29.9792E7

//每三位以逗号进行分隔。
System.out.println(new DecimalFormat(",###").format(c));		//299,792,458

//将格式嵌入文本
System.out.println(new DecimalFormat("光速大小为每秒,###米。").format(c));
```

# 三元操作符(?:)

```java
public class HelloWorld {
        public static void main(String[] args) {
            int i = 5;
            int j = 6;
            int k = i < j ? 99 : 88;
            // 相当于
            if (i < j) {
               k = 99;
            } else {
                k = 88;
            }
            System.out.println(k);
        }
}
```

# 控制流程

## if

```java
// 多表达式必须要用大括号阔起来；单一表达式可以不适应大括号（看起来简洁）-单一表达式不能在if后加分号

boolean b = false;
//如果有多个表达式，必须用大括弧包括起来
if (b){
    System.out.println("yes1");
    System.out.println("yes2");
    System.out.println("yes3");
}

//否则表达式2 3 无论b是否为true都会执行
if(b)
    System.out.println("yes1");
    System.out.println("yes2");
    System.out.println("yes3");

//如果只有一个表达式可以不用写括弧，看上去会简约一些
if(b){
    System.out.println("yes1");
}
if(b)
    System.out.println("yes1");
```

## switch    

**可以使用 byte, short, int, char, String, enum**

**注:** 每个表达式结束，都应该有一个**break**;

**注:** String在Java1.7之前是不支持的, Java从1.7开始支持switch用String的，编译后是把String转化为hash值，其实还是整数

```java
switch(day){
    case 1:
        System.out.println("星期一");
        break;
    case 2:
        System.out.println("星期二");
        break;
        // 剩余的数
    default:
        System.out.println("这个是什么鬼？");
```

## while     

while：条件为true时重复执行

do while：条件为true时重复执行，至少会执行一次

## 数组

```java
// 数组的定义 ：定义直接赋值
int[]  array = {1,2,3,4,5,6,7,8};
int  array[] = {1,2,3,4,5,6,7,8};

// 先定义后赋值
float[] array = new float[5];
array[0] = 10.5f;
// 打印数组 - for循环
for (int i = 0; i<array.length; i++){
    System.out.println(array[i]);
}
// for each循环
for (int i : array){
    System.out.println(i)
}
// 利用Array类中的toString方法
System.out.println(Arrays.toString(array));
```

## 数值与字符串互转

```java
// 字符转数值
String number = "100";
int sum = Integer.parseInt(number) + 200;
double sum = Double.parseDouble(number) + 200.5;
// 数值转字符
String number = "" + sum;
String number = String.valueOf(sum);
```

## 静态方法

static:

- 静态方法：
  - 可以直接调用静态成员
  - 不可以直接调用非静态成员
- 非静态方法：
  - 可以直接调用静态成员
  - 可以直接调用非静态成员
- 成员变量：
  - static :  对所有对象是否使用同一个值
- 成员方法：
  - static :  工具类中的方法

## THIS 关键字

```java
// 调用属性
this.name = "tim";
this.age = 12;
// 调用方法
this.print();
// 调用构造方法
// 如果使用，必须是构造方法第一条语句
this();
this("tim",12)
```

## 继承

super - 子类调用父类的构造方法，属性和方法

```java
// 访问父类属性
super.name ;
super.age ;
// 调用方法
this.print();
// 调用构造方法
// 如果使用，必须是构造方法第一条语句
this();
this("tim",12)
```

- 子类是对父类功能的扩展：
  
- 子类可以在父类的基础上添加属性，一般不要定义和父类同名的属性，可以重新父类的方法增强父类的功能。
  
- 子类对象创建，先调用弗雷德构造方法，默认调用无参构造器
  - 父类定义了带参的构造器：
    - 父类定义无参构造器（建议）
    - 在子类的构造器中使用super指定调用父类带参的构造器。
    - super调用父类的构造方法，必须在子类构造方法的第一条
    - this调用本类的构造方法，必须在子类构造方法的第一条语句

- 子类集成父类的私有方法，但是不继承父类的构造器（所以子类无法重写父类构造器）

- 代码执行顺序:

  - 父类：
    - 1.静态代码块  --> 2.非静态代码块 --> 3.构造方法
  - 子类
    - 4.静态代码块  --> 5.非静态代码块 --> 6.构造方法
  - 1 --> 4 --> 2 --> 3 --> 5 --> 6 

  

### 抽象类和方法

抽象类没有实例化

抽象方法所在的类，必须是抽象类、抽象类里卖弄可以没有抽象方法

- 设计抽象方法的目的是：

  抽象类就是设计骨架，可以规定子类的共同属性和方法，

```java
// 抽象类
pulice adstract class Test{
    // 抽象方法-只有定义没有实现，没有方法体{}
    pulice abstract void test(); 
}
```

子类集成抽象类，必须实现抽象类中的方法，（除开子类也是抽象类）。

### final

使用final后的类和方法不能再定义

- 修饰变量： 常量
- 修饰方法： 子类不能重写父类的final方法
- 修饰类： 该类不能被继承

## 多态

同一对象，调用相同的方法，执行不同的操作

- 重载的多态： 面向编译，静态绑定
- 重写的多态： 面向运行，动态绑定

- 多态实现的三步：	
  1. 子类重写父类的方法
  2. 程序运行时，子类对象赋给父类对象
  3. 通过父类调用方法，执行的时子类的方法
- 父类和子类的转换：
  - 向上转型：自动类型转换，安全
    - 父类=子类
  - 向下转型：不安全
    - 真转型：编译通过，运行时异常
    - 假转型：可以
- 多态的应用：
  - 使用父类类型作为方法的参数
  - 使用父类类型作为方法的返回值

## 接口

**interface：** 只有定义，没有实现

接口是什么：

- 接口不能被实例化

- 接口只能包含方法声明

- 接口的成员包括方法、属性、索引器、事件

- 接口中不能包含常量、字段(域)、构造函数、析构函数、静态成员

接口的使用：

1. 派生类必须实现接口中未实现的方法，抽象类除外
2. 一个类可以实现多个接口（所以 Java 虽然是单继承，但是可以通过接口实现类似多继承的用法）

