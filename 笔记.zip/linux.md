---
title: Linux基础命令
date: 2018-09-06 12:27:34
tags:
---
##  Linux树形结构目录

| /              | 根目录                                 |
| -------------- | -------------------------------------- |
| ├── bin        | 存放用户二进制文件                     |
| ├── boot       | 存放内核引导配置文件                   |
| ├── dev        | 存放设备文件                           |
| ├── etc        | 存放系统配置文件                       |
| ├── home       | 用户主目录                             |
| ├── lib        | 动态共享库                             |
| ├── lost+found | 文件系统恢复时的恢复文件               |
| ├── media      | 可卸载存储介质挂载点                   |
| ├── mnt        | 文件系统临时挂载点                     |
| ├── opt        | 附加的应用程序包                       |
| ├── proc       | 系统内存的映射目录，提供内核与进程信息 |
| ├── root       | root 用户主目录                        |
| ├── sbin       | 存放系统二进制文件                     |
| ├── srv        | 存放服务相关数据                       |
| ├── sys        | sys   虚拟文件系统挂载点               |
| ├── tmp        | 存放临时文件                           |
| ├── usr        | 存放用户应用程序                       |
| └── var        | 存放邮件、系统日志等变化文件           |

# linux杀进程

```shell
$ ps -ef | grep *  # 查找进程ID
$ ps -e --forest | grep * # 显示进程数
$ kill - 9 ID  # 杀死当前进程的ID
－－－－－－－－－－－－－－－－－－
$ killall -9 * # 直接杀死当前进程（包含这个进程的所有ID）
```

| Signal Name | Single Value |     Effect     |
| :---------: | :----------: | :------------: |
|   SIGHUP    |      1       |      挂起      |
|   SIGINT    |      2       | 键盘的中断信号 |
|   SIGKILL   |      9       |  发出杀死信号  |
|   SIGTERM   |      15      |  发出终止信号  |
|   SIGSTOP   |   17,19,23   |    停止进程    |

## linux常用命令

| bash命令             | 解释                                                         |
| -------------------- | ------------------------------------------------------------ |
| ls                   | 显示文件或目录                                               |
| mkdir   [-p]         | 创建目录 [若无父目录，则创建父目录]                          |
| cd                   | 切换目录                                                     |
| touch                | 创建空文件                                                   |
| echo                 | 输出                                                         |
| cat                  | 查看文件内容                                                 |
| cp                   | 拷贝                                                         |
| mv                   | 移动                                                         |
| rm   [-r]   [-f]     | 删除文件 [递归删除，可删除子目录及文件] [强制删除]           |
| find                 | 在文件系统中搜索文件                                         |
| wc                   | 统计文本中行数、字数、字符数                                 |
| grep                 | 在文本文件中查找某个字符                                     |
| rmdir                | 删除 空目录                                                  |
| tree                 | 树形结构显示目录，需要安装tree包                             |
| pwd                  | 显示当前目录                                                 |
| ln                   | 创建链接文件                                                 |
| more/less            | 分页显示文本文件内容                                         |
| head/tail            | 显示文件头、尾文件                                           |
| stat                 | 显示指定文件的详细信息，比ls更详细                           |
| who                  | 显示在线登陆用户                                             |
| whoami               | 显示当前操作用户                                             |
| hostname             | 显示主机名                                                   |
| uname                | 显示系统信息                                                 |
| top                  | 动态显示当前耗费资源最多的进程                               |
| ps                   | 显示瞬间进程状态 ps -aux                                     |
| du                   | 查看目录大小 du -h /home带有单位显示目录信息                 |
| df                   | 查看磁盘大小 df -h 带有单位显示磁盘信息                      |
| ping                 | 测试网络                                                     |
| netstat              | 显示网络状态                                                 |
| clear                | 清屏                                                         |
| alias                | 对命令重命名 如 alias showmeit="ps -aux",另外接触使用 unalias showmeit |
| shutdown             | [-r] 关机重启     [- h]关机不重启    [now]立刻关机           |
| halt                 | 关机                                                         |
| reboot               | 重启                                                         |
| du -ah --max-depth=1 | 查询文件夹大小                                               |

## linux打包压缩

Linux下常见的压缩包格式有5种:zip tar.gz tar.bz2 tar.xz tar.Z

其中tar是种打包格式,gz和bz2等后缀才是指代压缩方式:gzip和bzip2

**tar**	打包(cvzf) 压缩(xvzf)

​	-c  压缩文件

​	-x 归档文件

​	-z gzip压缩文件

​	-j bzip2压缩文件

​	-v 显示压缩解压缩过程

​	-f 使用文档名

## linux用户及组管理

```shell
useradd		[username]

userdel		[username]

adduser		[username]

groupadd	[groupname]

groupdel	[groupname]

passwd root		# 给root设置密码
su use			# 切换用户,加载配置文件.bashrc
su - user		# 切换用户，加载配置文件/etc/profile，加载bash_profile,更改文件的用户及用户组
chown [-R] owner[:group] {File|Directory} # 例 ：chown root:root jdk-8u211.tar
```

## linux文件权限

- 三种基本权限
  - R         读            数值表示为4
  - W        写            数值表示为2
  - X      可执行        数值表示为1

- 更改权限
  - chmod     [u所属用户     g所属组    o其他用户    a所有用户]   [+增加权限   -减少权限]    [r w x]  [目录名]

  - 此外chmod也可以用数字来表示权限如：

    chmod   777   [filename]

## linux管道

- 管道是什么：

  - 管道是一种通讯机制，通常用于进程间的通信(也可以通过socket进行网络通信)，它表现出现的新形式就是将前面的每一个命令的输出(stdout)直接作为下一个命令的输入(stdin)

  - 例如：grep -r "close" /home/* | more  在home目录下所有文件查找，包括close的文件，并分页输出

## linux sort

工作原理：

sort将文件的每一行作为一个单位，相互比较，比较原则是从首字符向后，依次按ASCII码值进行比较，最后将他们按升序输出。

```shell
$ ll | sort -rnk 5|head -3
# 将文件按顺序输出
$ cat test.txt
a
c
b
$ sort test.txt
a
b
c
```

sort  -u    ---    去除重复行

```shell 
$ cat test
a
c
c
b
$ sort -u test
a
b
c
```

sort   -r    ---     排序方式改为降序

```shell
$ cat test
a
c
b
$ sort -r test
c
b
a
```

sort   -r text.txt -o text.txt    ---    将输出结果写入原文件

```powershell
$ cat test
a
c
b
$ sort - r test -o test
c
b
a
$ cat test
c
b
a
```

sort   -n test.txt     ---     sort默认字符排序，-n 告诉sort 要以数值排序

```shell
$ cat test
1
3
2
$ sort -n test
1
2
3
```

**其他的sort常用选项**:

-f	会将小写字母都转换为大写字母来进行比较，亦即忽略大小写

-c	会检查文件是否已排好序，如果乱序，则输出第一个乱序的行的相关信息，最后返回1

-C	会检查文件是否已排好序，如果乱序，不输出内容，仅返回1

-M	会以月份来排序，比如JAN小于FEB等等

-b	会忽略每一行前面的所有空白部分，从第一个可见字符开始比较。

