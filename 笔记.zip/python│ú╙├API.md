---
title: Python常用API
date: 2018-10-13 18:31:52
tags:
---

## heapq

**使用heapq模块的nlargest()和nsmallest()来查找最大或最小的N个元素**

| 方法名                         | 简介                     |
| :----------------------------- | :----------------------- |
| nsmallest(n,iterable,key=None) | 获取列表里面最小的几个值 |
| nlargest(n,iterable,key=None)  | 获取列表里面最大的几个值 |

```python
Import heapq
nums=[1,8,5,-3,-78,23,9,45]
print(heapq.nlargest(3,nums)) 	# 获取列表里面最大的几个值
print(heapq.nsmallest(3,nums))  # 获取列表里面最小的几个值
portfolio=[
{'name':'IBM','shares':100,'price':91.1},
{'name':'AAPL','shares':50,'price':543.22},
{'name':'FB','shares':200,'price':21.09},
{'name':'HPQ','shares':35,'price':31.75},
{'name':'YHOO','shares':45,'price':16.35},
{'name':'ACME','shares':75,'price':115.65}
]
Cheap = heapq.nsmallest(3,portfolio,key=lambdas:s['shares'])
Expensive = heapq.nlargest(3,portfolio,key=lambdas:s['price'])
print(cheap)
```

## collections

```python
from collections import Counter
# 获得列表出现次数最多的元素
words = [
    'look', 'into', 'my', 'eyes', 'look', 'into', 'my', 'eyes',
    'the', 'eyes', 'the', 'eyes', 'the', 'eyes', 'not', 'around',
    'the', 'eyes', "don't", 'look', 'around', 'the', 'eyes',
    'look', 'into', 'my', 'eyes', "you're", 'under'
]
counter = Counter(words)
print(counter.most_common(3)) # 获得出现次数最多的三个元素
>>> [('eyes', 8), ('the', 5), ('look', 4)]
```



## BeautifulSoup

解析HTML

 **select()方法寻找元素：**

| **传递给** select()方法的选择器     | 将匹配…                                                    |
| ----------------------------------- | ---------------------------------------------------------- |
| soup.select('div')                  | 所有名为\<div>的元素                                       |
| soup.select('#author')              | 带有 id 属性为 author 的元素                               |
| soup.select('.notice')              | 所有使用 CSS class 属性名为 notice 的元素                  |
| soup.select('div span')             | 所有在\<div>元素之内的\<span>元素                          |
| soup.select('div > span')           | 所有直接在\<div>元素之内的\<span>元素，中间没有其他元素    |
| soup.select('input[name]')          | 所有名为\<input>，并有一个 name 属性，其值无所谓的元素     |
| soup.select('input[type="button"]') | 所有名为\<input>，并有一个 type 属性，其值为 button 的元素 |

## json

- **loads()** - 将json数据转化成dict数据
- **dumps()** - 将dict数据转化成json数据
- **load()** - 读取json文件数据，转成dict数据
- **dump()** - 将dict数据转化成json数据后写入json文件

```python
# dict字典转json数据
dt = {'name':'tom','age':'11'}
js = json.dumps(dt)
# json数据转dict字典
d = json.loads(js)
```

## 抛出异常

抛出异常使用 raise 语句。在代码中，raise 语句包含以下部分：

- raise 关键字
- 对 Exception 函数的调用
- 传递给 Exception 函数的字符串，包含有用的出错信息

```python
raiseException('Thisistheerrormessage.')
```

## 日志模块

```python
>>> import logging
>>> logging.basicConfig(level=logging.DEBUG,
                        format='%(asctime)s-%(levelname)s-%(message)s')
>>> logging.debug('Startofprogram')
>>> logging.debug('Endofprogram')
```

| 参数                        | 简介                                                         |
| --------------------------- | ------------------------------------------------------------ |
| filename                    | 指定日志文件名                                               |
| filemode                    | 和file函数意义相同，指定日志文件的打开模式，'w'或'a'         |
| format                      | 指定输出的格式和内容，format可以输出很多有用信息，如上例所示 |
| %(levelno)s                 | 打印日志级别的数值                                           |
| %(levelname)s               | 打印日志级别名称                                             |
| %(pathname)s                | 打印当前执行程序的路径，其实就是sys.argv[0]                  |
| %(filename)s                | 打印当前执行程序名                                           |
| %(funcName)s                | 打印日志的当前函数                                           |
| %(lineno)d                  | 打印日志的当前行号                                           |
| %(asctime)s                 | 打印日志的时间                                               |
| %(thread)d                  | 打印线程ID                                                   |
| %             (threadName)s | 打印线程名称                                                 |
| %(process)d                 | 打印进程ID                                                   |
| %(message)s                 | 打印日志信息                                                 |
| datefmt                     | 指定时间格式，同time.strftime()                              |
| level                       | 设置日志级别，默认为logging.WARNING                          |
| stream                      | 指定将日志的输出流，可以指定输出到sys.stderr,sys.stdout或者文件，默认输出到sys.stderr，当stream和filename同时指定时，stream被忽略 |

日志级别:

|级别|日志函数|描述|
|-|-|-|
DEBUG|logging.debug()|最低级别。用于小细节。通常只有在诊断问题时，你才会关心这些消息|
INFO|logging.info()|用于记录程序中一般事件的信息，或确认一切工作正常|
WARNING|logging.warning()|用于表示可能的问题，它不会阻止程序的工作，但将来可能会|
ERROR|logging.error()|用于记录错误，它导致程序做某事失败|
CRITICAL|logging.critical()|最高级别。用于表示致命的错误，它导致或将要导致程序完全停止工作|

禁用日志:

在调试完程序后，你可能不希望所有这些日志消息出现在屏幕上。logging.disable() 函数禁用了这些消息，这样就不必进入到程序中，手工删除所有的日志调用。只要向 logging.disable() 传入一个日志级别，它就会禁止该级别和更低级别的所有日志消息。所以，如果想要禁用所有日志，只要在程序中添加 logging. disable（logging.CRITICAL）