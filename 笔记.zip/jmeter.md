---
title: Jmeter基础	
date: 2018-11-27 12:21:02
tags:Jmeters
---
## 安装jmeter
下载：https://jmeter.apache.org/download_jmeter.cgi

## jmeter工作原理

jmeter可以作为web服务器与浏览器直接的代理网关，以便捕获浏览器的请求和web服务器的响应，如此就可以很容易地生成性能测试脚本。有了性能测试脚本，jmeter就可以通过线程来模拟真实用户对web服务器的访问压力，

jmeter的基本原理是建立一个线程池，多线程运行取样器产生大量的负载，再运行过程中通过断言来验证结果的准确性，通过监听器来记录测试结果。

## jmeter体系结构



## jmeter用法:       

添加线程组:      测试计划 - 添加 - Threads
添加请求:        线程组 - 添加 - Sample - HTTP请求
查看结果:        线程组 - 添加 - 监听器 - 查看结果树

## Jmeter常用插件：

|插件名|作用|
|-|-|
|Active Threads Over Time|活动线程随时间的变化|
|Connect Times Over Time|连接时间|
|Response Times Over Time|响应时间|
|Transactions per Second|每秒事务数|
|PerfMon Metrics Collector|性能指标收集器|
|Response Times Percentiles|响应时间百分位数|
|Response Latencies Over Time|响应延迟时间|
|Response Times vs Threads|响应时间vs线程|
|Transaction Throughput vs Threads|事务吞吐量vs线程|

