---
title: Selenium
date: 2018-7-19 12:27:34
tags:
---
chromedriver: http://chromedriver.storage.googleapis.com/index.html

firefoxdriver: https://github.com/mozilla/geckodriver/releases/

## WebDriver方法

WebDriver对象有好几种方法，用于在页面中寻找元素。它们被分成find_element_*和find_elements_*方法。find_element_*方法返回一个 WebElement 对象，代表页面中
匹配查询的第一个元素。find_elements_*方法返回 WebElement_*对象的列表，包含页面中所有匹配的元素。
selenium 的 WebDriver 方法，用于寻找元素：


|方法名|返回的 WebElement 对象/列表|
|-|-|
browser.find_element_by_class_name(name)|使用 CSS 类 name 的元素|
browser.find_elements_by_class_name(name)|-|
browser.find_element_by_css_selector(selector)|匹配 CSS selector 的元素|
browser.find_elements_by_css_selector(selector)|-|
browser.find_elements_by_link_text(text)|完全匹配提供的 text 的<a>元素|
browser.find_element_by_link_text(text)|-|
browser.find_elements_by_partial_link_text(text)|包含提供的 text 的<a>元素|
browser.find_element_by_partial_link_text(text)|-|
browser.find_element_by_name(name)|匹配 name 属性值的元素|
browser.find_elements_by_name(name)|-|
browser.find_element_by_tag_name(name)|匹配标签 name 的元素|
browser.find_elements_by_tag_name(name)|(大小写无关，<a>元素匹配'a'和'A')|

## WebElement
WebElement 的属性和方法

|属性或方法|描述|
|-|-|
tag_name|标签名，例如 'a'表示<a>元素|
get_attribute(name)|该元素 name 属性的值|
Text|该元素内的文本，例如<span>hello</span>中的'hello'|
clear()|对于文本字段或文本区域元素，清除其中输入的文本|
is_displayed()|如果该元素可见，返回 True，否则返回 False|
is_enabled()|对于输入元素，如果该元素启用，返回 True，否则返回 False|
is_selected()|对于复选框或单选框元素，如果该元素被选中，选择 True，否则返回 False|
Location|一个字典，包含键'x'和'y'，表示该元素在页面上的位置|

## 模拟键盘侠
selenium 有一个模块，针对不能用字符串值输入的键盘击键。它的功能非常类似于转义字符。这些值保存在 selenium.webdriver.common.keys 模块的属性中。
由于这个模块名非常长，所以在程序顶部运行 from selenium.webdriver. common.keys importKeys 就比较容易。
如果这么做，原来需要写 from selenium. webdriver.common.keys 的地方，就只要写 Keys。
selenium.webdriver.common.keys 模块中常用的变量：

|属性|含义|
|-|-|
Keys.DOWN, Keys.UP, Keys.LEFT,Keys.RIGHT|键盘箭头键|
Keys.ENTER, Keys.RETURN	|回车和换行键|
Keys.HOME, Keys.END,Keys.PAGE_DOWN,Keys.PAGE_UP|Home 键、End 键、PageUp 键和 Page Down 键|
Keys.ESCAPE, Keys.BACK_SPACE,Keys.DELETE|Esc、Backspace 和字母键|
Keys.F1, Keys.F2, . . . , Keys.F12|键盘顶部的 F 1 到 F 12 键|
Keys.TAB|Tab 键|

## 模拟浏览器按钮
selenium 也可以模拟点击各种浏览器按钮

|属性|含义|
|-|-|
browser.back()|点击“返回”按钮|
browser.forward()|点击“前进”按钮|
browser.refresh()|点击“刷新”按钮|
browser.quit()|点击“关闭窗口”按钮|

## selenium的等待方式
- 隐式等待：implicitly_wait(xx)  #xx填写隐式等待的时间
- 显示等待：Webdriver参数和方法：selenium.webdriver.support.wait.WebDriverWait（类）

|__init__|	|
|-|-|
driver|传入WebDriver实例，即我们上例中的driver|
timeout|超时时间，等待的最长时间（同时要考虑隐性等待时间|
poll_frequency|调用until或until_not中的方法的间隔时间，默认是0.5秒|
ignored_exceptions|忽略的异常，如果在调用until或until_not的过程中抛出这个元组中的异常，则不中断代码，继续等待，如果抛出的是这个元组外的异常，则中断代码，抛出异常默认只有NoSuchElementException。|
until|	|	
method|在等待期间，每隔一段时间调用这个传入的方法，直到返回值不是False|
message|如果超时，抛出TimeoutException，将message传入异常|
until_not|与until相反，until是当某元素出现或什么条件成立则继续执行|

**WebDriverWait(driver, 超时时长, 调用频率, 忽略异常).until(可执行方法, 超时时返回的信息)**
```python
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
			driver = webdriver.Firefox()
driver.get("http://somedomain/url_that_delays_loading")
try:
    element = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, "myDynamicElement"))
    )
finally:
    driver.quit()
```
## 下拉框处理
利用Select模块处理下拉框
```python
from selenium.webdriver.support.select import Select
Select提供了三种选择某一项的方法
select_by_index	通过索引定位；index索引是从“0”开始；
select_by_value	通过value值定位；value是option标签的一个属性值，并不是显示在下拉框中的值；
select_by_visible_text	通过文本值定位；visible_text是在option标签中间的值，是显示在下拉框的值；
Select(下拉框定位).select_by_(三种方法之一)
```

## **Selenium Grid**

Selenium Grid主要用于分布式执行测试，