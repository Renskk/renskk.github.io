---
title: docker下使用MySQL
date: 2019-05-23 12:27:34
tags:
---

## docker中搜索可用镜像

  ```shell
$ docker search mysql
  ```

## 获取mysql镜像

  ```shell
$ docker pull mysql
  ```

## 运行docker下mysql

  ```shell
$ docker run --name mysql -e MYSQL_ROOT_PASSWORD=123456 -d -i -p 3306:3306 --restart=always  mysql
# 创建容器的时候就指定utf8编码
$ docker run --name mysql_dev -e MYSQL_ROOT_PASSWORD=123456 -d -i -p 3306:3306  -d mysql --character-set-server=utf8mb4 --collation-server=utf8mb4_unicode_ci 
# 以上参数定义
  --name mysql  将容器命名为mysql，后面可以用这个name进行容器的启动暂停等操作
  -e MYSQL_ROOT_PASSWORD=123456 设置MySQL密码为123456
  -d 此容器在后台运行,并且返回容器的ID
  -i 以交互模式运行容器
  -p 进行端口映射，格式为主机(宿主)端口:容器端口
  --restart=always 当docker重启时，该容器自动重启
  ```

## 进入MySQL容器

  ```shell
$ docker exec -ti mysql bash
  ```

## MySQL中文乱码

  ```mysql
$ show variables like 'character_set%'; # 查看mysql字符集
  ```

  ```shell
# 修改/etc/mysql/my.cnf
#在[]便签下添加如下参数配置
[mysqld]
default-character-set = utf8
character_set_server = utf8
[mysql]
default-character-set = utf8
[mysql.server]
default-character-set = utf8
[mysqld_safe]
default-character-set = utf8
[client]
default-character-set = utf8
  ```

  

[linux下安装navicat]: https://www.jianshu.com/p/cc6921d79767

## Mysql授权用户

老版MySQL创建数据库用户并授权

```mysql
grant all privileges on db_sonar.* to '用户名'@'%'identified by '密码' with grant option;
flush privileges;
```

**新版的mysql将创建账户和赋予权限的方式分开了**

```mysql
// 创建用户
create user 'sonar'@'%'identified by '123456';
// 修改权限
grant all privileges on db_sonar.* to 'sonar'@'%' with grant option;
```

