---
title: Python进阶
date: 2018-10-12 12:27:34
tags:
---

## 冒泡排序

```python
def select_bub(origin_items, comp=lambda x, y : x > y ):
    items = origin_items
    for i in range(len(items) - 1):
        for j in range(len(items) - i - 1):
            if comp(items[j], items[j+1]):
                items[j], items[j+1] = items[j+1], items[j]
    return items
```

## 选择排序

```python
def select_sort(origin_items, comp=lambda x, y : x < y ):
    items = origin_items
    for i in range(len(items) - 1):
        min_items = i
        for j in range(i+1, len(items)):
            if comp(items[j], items[min_items]):
                min_items = j
        items[i], items[min_items] = items[min_items], items[i]
    return items
```

## 生成式语法

```python
prices = {
    'AAPL': 191.88,
    'GOOG': 1186.96,
    'IBM': 149.24,
    'ORCL': 48.44,
    'ACN': 166.89,
    'FB': 208.09,
    'SYMC': 21.29
}
# 用股票价格大于100元的股票构造一个新的字典
new_prices = {key: value for key, value in prices.items() if value > 100}
print(new_prices)
```

## 常用算法

- 穷举法 - 又称为暴力破解法，对所有的可能性进行验证，直到找到正确答案。
- 贪婪法 - 在对问题求解时，总是做出在当前看来
- 最好的选择，不追求最优解，快速找到满意解。
- 分治法 - 把一个复杂的问题分成两个或更多的相同或相似的子问题，再把子问题分成更小的子问题，直到可以直接求解的程度，最后将子问题的解进行合并得到原问题的解。
- 回溯法 - 回溯法又称为试探法，按选优条件向前搜索，当搜索到某一步发现原先选择并不优或达不到目标时，就退回一步重新选择。
- 动态规划 - 基本思想也是将待求解问题分解成若干个子问题，先求解并保存这些子问题的解，避免产生大量的重复运算。

## 单例模式

摘抄自：http://funhacks.net/2017/01/17/singleton/

**单例模式（Singleton Pattern）**是一种常用的软件设计模式，该模式的主要目的是确保**某一个类只有一个实例存在**。当你希望在整个系统中，某个类只能出现一个实例时，单例对象就能派上用场

在 Python 中，我们可以用多种方法来实现单例模式：

### 使用模块

其实，**Python 的模块就是天然的单例模式**，因为模块在第一次导入时，会生成 `.pyc` 文件，当第二次导入时，就会直接加载 `.pyc` 文件，而不会再次执行模块代码。因此，我们只需把相关的函数和数据定义在一个模块中，就可以获得一个单例对象了。如果我们真的想要一个单例类，可以考虑这样做：

```python
# mysingleton.pyclass 
My_Singleton(object):    
    def foo(self):        
passmy_singleton = My_Singleton()
```

将上面的代码保存在文件 mysingleton.py中，然后这样使用：

```python
from mysingleton import my_singletonmy_singleton.foo()
```

### 使用 `__new__`

为了使类只能出现一个实例，我们可以使用 `__new__ `来控制实例的创建过程，代码如下：

```python
class Singleton(object):
    _instance = None
    def __new__(cls, *args, **kw):
        if not cls._instance:
            cls._instance = super(Singleton, cls).__new__(cls, *args, **kw)  
        return cls._instance  
class MyClass(Singleton):  
    a = 1
```

在上面的代码中，我们将类的实例和一个类变量 `_instance` 关联起来，如果 `cls._instance` 为 None 则创建实例，否则直接返回 `cls._instance`。

执行情况如下：

```python
>>> one = MyClass()
>>> two = MyClass()
>>> one == two
True
>>> one is two
True
>>> id(one), id(two)
(4303862608, 4303862608)
```

### 使用装饰器

我们知道，装饰器（decorator）可以动态地修改一个类或函数的功能。这里，我们也可以使用装饰器来装饰某个类，使其只能生成一个实例，代码如下：

```python
from functools import wraps
def singleton(cls):
    instances = {}
    @wraps(cls)
    def getinstance(*args, **kw):
        if cls not in instances:
            instances[cls] = cls(*args, **kw)
        return instances[cls]
    return getinstance
@singleton
class MyClass(object):
    a = 1
```

在上面，我们定义了一个装饰器 `singleton`，它返回了一个内部函数 `getinstance`，该函数会判断某个类是否在字典 `instances` 中，如果不存在，则会将 `cls` 作为 key，`cls(*args, **kw)` 作为 value 存到 `instances` 中，否则，直接返回 `instances[cls]`

### 使用 metaclass

元类（metaclass）可以控制类的创建过程，它主要做三件事：

- 拦截类的创建
- 修改类的定义
- 返回修改后的类

使用元类实现单例模式的代码如下：

```python
import threading

class SingletonMeta(type):
    """自定义元类"""

    def __init__(cls, *args, **kwargs):
        cls.__instance = None
        cls.__lock = threading.Lock()
        super().__init__(*args, **kwargs)

    def __call__(cls, *args, **kwargs):
        if cls.__instance is None:
            with cls.__lock:
                if cls.__instance is None:
                    cls.__instance = super().__call__(*args, **kwargs)
        return cls.__instance
    
class President(metaclass=SingletonMeta):
    """总统(单例类)"""
    pass
```

## 迭代器

迭代器就是用于迭代操作（for 循环）的对象，它像列表一样可以迭代获取其中的每一个元素，任何实现了 `__next__` 方法的对象都可以称为迭代器

以斐波那契数列为例来实现一个迭代器：

```python
class Fib(object):
    """迭代器"""
    
    def __init__(self, num):
        self.num = num
        self.a, self.b = 0, 1
        self.idx = 0
   
    def __iter__(self):
        return self

    def __next__(self):
        if self.idx < self.num:
            self.a, self.b = self.b, self.a + self.b
            self.idx += 1
            return self.a
        raise StopIteration()
```

## 生成器

普通函数用 `return` 返回一个值，和 Java 等其他语言是一样的，然而在 Python 中还有一种函数，用关键字 `yield` 来返回值，这种函数叫生成器函数，函数被调用时会返回一个生成器对象，生成器本质上还是一个迭代器，也是用在迭代操作中，因此它有和迭代器一样的特性，唯一的区别在于实现方式上不一样，后者更加简洁

以斐波那契数列为例来实现一个生成器：

```python
def fib(num):
    """生成器"""
    a, b = 0, 1
    for _ in range(num):
        a, b = b, a + b
        yield a

a = fib(6)
print([i for i in a])
```

```python
>>> g = (x*2 for x in range(10)) # 使用()返回生成器对象
>>> type(g)
<type 'generator'>
>>> l = [x*2 for x in range(10)] # 使用[]返回列表对象
>>> type(l)
<type 'list'>
```

## 并发编程

Python中实现并发编程的三种方案：多线程、多进程和异步I/O。并发编程的好处在于可以提升程序的执行效率以及改善用户体验；坏处在于并发的程序不容易开发和调试，同时对其他程序来说它并不友好

进程和线程的区别和联系

- 进程 - 操作系统分配内存的基本单位 - 一个进程可以包含一个或多个线程
- 线程 - 操作系统分配CPU的基本单位

并发编程（concurrent programming）
- 提升执行性能 - 让程序中没有因果关系的部分可以并发的执行
- 改善用户体验 - 让耗时间的操作不会造成程序的假死

