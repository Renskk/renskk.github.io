---
title: JS基础
date: 2018-11-03 12:27:34
tags:
---

## JS的三种引入方式

- 直接在时间属性中写js代码
- 在script标签中写js代码
- 外部引入

### js和java的区别

- 编译型语言：强类型的语言，先编译后运行
- 解释型语言：弱类型的语言，直接运行

### 方法

在js中方法也是对象，实际上js内置了一些数据类型：Math、String、Array、Function

```javascript
function sort(a, b){return a - b}
var sort = function(a, b){return a - b}
var sort = new Function("a", "b",  "return a - b;")
```

### API

全局的函数：属window的函数，因为window代指的是整个浏览器对象，所以整个浏览器中就只有一个window，没有歧义，所以在调动全局函数或者全局变量的时候就可以省略window

```javascript
window.isNaN(obj)
window.parseInt(obj)
window.parseFloat(obj)
window.alert(obj)
```

console相关的函数

```javascript
window.console.log(obj)
window.console.dir(obj)
```

document相关的函数

```javascript
window.docunment.getElementById(id)
```

Math相关的函数

```javascript
Math.random()
Math.floor()
Math.ceil()
Math.round()
```

String相关的函数

```javascript
str.toLowerCase()
str.toUpperCase()
str.charAt(index)
str.indexOf(substr)
str.lastIndexOf(substr)
str.subString(start,[end])
str.replace(reg,tostr)
str.split()
```

Array相关的函数

```javascript
arr.reverse()
arr.sort(func)
```

Date相关的函数

```javascript
getDate() // 获取月份中的天
getDay() // 获取星期，范围是0-6，0代表周日
getFullYear() // 获取年份
getYear() // 获取1900距今的差值
setDate() // 设置月份中的天
setYear() // 设置年份
toString()
toLocalString() // 获取本地格式的日期字符串
toLocalDateString() // 年 月 日
toLacalTimeString() // 时 分 秒
```

### 事件

- onclick: 当点击对应元素的时候触发JS代码
- onblur: 当失去焦点的时候触发JS代码
- onload: 当加载完毕dom树的时候执行，在html元素上声明

### 定时器

- 重复执行定时器

  ```javascript
  // 按照指定时间重复的执行对应的函数，返回一个定时器对象
  // 该方法每调用一次，就会创建一个新的定时器对象
  window.setInterval(func, mills) 
  window.clearInterval(timer)
  ```

- 一次性定时器

  ```javascript
  // 按照指定的时间延迟
  window.setTimeout(func,mills)
  window.clearTimeout(timer)
  ```

### DOM

brower object model - 浏览器对象模型

```js
window // 整个浏览器的信息都被封装在该对象中
	- alert()
	- confirm(tips) // 弹出一个提示框，点击确认返回true，点击取消返回false
	- prompt([标题],[data]) // 弹出一个提示框，点击确认返回输入的值，点击取消返回null
	- open(addr) // 打开指定的网页
	- close() // 关闭当前页面
    - history // 封装了历史信息
    - navigator // 封装了导航信息
    - document // 封装了所有页面的信息
    - location //封装了地址栏的所有信息
        - reload() // 刷新
    - screen // 封装了屏幕信息
    - event // 事件对象
```

元素

- 元素是节点的一种
- 在DOM中，所有的元素节点都隶属于document对象，浏览器加载对应元素的html代码后就生成对应的对象
- 每一个元素对象都由很多属性构成的，常用的属性：
  - value： 值
  - style：封装的是所有样式信息
  - innerHTML：内部的HTML，封装了元素内部（开始标记喝结束标记之间）的所有超文本，包含了对应的标签
  - innerText：内部的文本，封装了元素内部的纯文本
  - className：封装的class属性的值
  - id：封装了id属性的值

查找结点

- 根据结构查找

  - childNodes：该属性封装了元素节点的所有子节点信息，是一个数组
  - nextSibing：该属性指代的是该节点的下一个节点
  - previousSibing：该属性指代的是该节点的上一个节点
  - fristChild：该属性指代的是该节点的第一个子节点
  - lastChild：该属性代指的是该节点的最后一个子节点
  - parentNode：该属性代指的是该节点的父节点

- 跨结构查找

  ```
  document.getElementById()
  document.getElementsByTagName()
  document.getElementsByClassName()
  ```

  























