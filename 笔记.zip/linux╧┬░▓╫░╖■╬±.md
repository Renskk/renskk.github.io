---
title: WSL基础
date: 2019-05-20 12:27:34
tags:
---
# WSL.UBUNTU
## WSL安装mysql
### 更新apt源

```shell
# 备份源文件
$ sudo cp /etc/apt/sources.list /etc/apt/sources.list.bak
# 编辑源文件列表
$ sudo vim /etc/apt/sources.list
# 使用[国内镜像源](https://blog.csdn.net/xiangxianghehe/article/details/80112149)替换原声源
# 更新apt
$ sudo apt update
```
### 安装MYSQL服务器版

```shell
$ sudo apt install mysql-server
```
### 启动MYSQL

```shell
# mysql是rpm安装的
#启动mysql
$ service mysqld start
#关闭mysql
$ service mysqld stop
# 二进制和源码安装的
#启动mysql
$ /etc/init.d/mysqld start
#关闭mysql
$ /etc/init.d/mysqld stop | /usr/bin/mysqladmin -u root -p shutdown
#重启mysql    
$ /etc/init.d/mysqld restart
```
### MYSQL可能出现的问题

```shell
$ ERROR 2002 (HY000): Can't connect to local MySQL server through socket '/var/run/mysqld/mysqld.sock' (2)
```
> 方案1
```shell
 $ ps -A|grep mysql
 # 显示类似：
 $ 1829 ?        00:00:00 mysqld_safe
 $ 1876 ?        00:00:31 mysqld
 $ kill -9 1829
 $ kill -9 1876
 $ /etc/init.d/mysql restart
 $ mysql -u root -p
```

> 方案2
```shell
# 先查看mysql是否已经启动
$ /etc/rc.d/init.d/mysqld status 
# 另外看看是不是权限问题.
$ chown -R mysql:mysql /var/lib/mysql
$ /etc/init.d/mysqld start
$ 启动 MySQL： [ 确定 ]
$ mysqladmin -uroot password '123456'
$ mysql -uroot -p
```
> 方案3
```shell
max_connections=1000 他说太多了，然后改成500也说多，无奈删之问题解决了。
```
> 方案4
```shell
$ /var/lib/mysql 
# 所有文件权限 改成mysql.mysql
```
> 方案5

摘要：解决不能通过mysql .sock连接MySQL问题 这个问题主要提示是，不能通过 '/tmp/mysql .sock'连到服务器，而php标准配置正是用过'/tmp/mysql .sock'，但是一些mysql 安装方法 将 mysql .sock放在/var/lib/mysql .sock或者其他的什么地方，你可以通过修改/etc/my.cnf文件来修正它，打开文件，可以看到如下的东东：

```shell
 [mysql d] 
 socket=/var/lib/mysql .sock 
 # 改一下就好了，但也会引起其他的问题，如mysql 程序连不上了，再加一点： 
 [mysql] 
 socket=/tmp/mysql .sock 
 或者还可以通过修改php.ini中的配置来使php用其他的mysql .sock来连，这个大家自己去找找
 或者用这样的方法:ln -s /var/lib/mysql /mysql .sock /tmp/mysql .sock
```
### 在windows下连接WSL中的MySQL

```shell
# 当连接提示报错是因为MySQL把 Windows 下的程序的连接视为远程 MySQL 请求，若你使用的 MySQL 用户没有远程权限，则会出错
# 解决方法，WSL进入mysql中 
$ use mysql;
$ update user set host = '%' where user = 'root';
$ GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' IDENTIFIED BY '' WITH GRANT OPTION;
$ FLUSH PRIVILEGES;
# 现在就可以使用 root 账户连接，无密码
```
## WSL安装java

1、从官网下载tar.gz结尾的java压缩包，放到/opt/目录下解压
2、输入命令vim /etc/profile，打开环境变量配置文件在文件底部输入以下信息，并保存
```shell
JAVA_HOME=/home/java/jdk1.8.0_131
JRE_HOME=$JAVA_HOME/jre
PATH=$PATH:$JAVA_HOME/bin
CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar
export JAVA_HOME
export JRE_HOME
export PATH
export CLASSPATH
```
3、建立连接/usr/bin/java的超链接

```shell
ln -s /home/java/jdk1.8.0_131/bin/java /usr/bin/java
```

4、配置生效

```shell
source /etc/profile
```



