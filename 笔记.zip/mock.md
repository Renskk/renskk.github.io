---
title: Mock基础
date: 2019-06-02 12:27:34
tags:
---
## 如何解决依赖产生的痛点
1、使用代理工具实现MOCK服务器
2、在测试中代码mock，写个mock服务
3、真实写个临时接口返回
## mock介绍
- unittest.mock是一个用于在Python中进行测试的库。它允许你使用模拟对象替换受测试系统的部分，检查调用并对如何使用它们进行断言。
- unittest.mock提供了一个核心Mock类，还有MagicMock.
	- 执行操作后，您可以断言使用哪种方法/属性以及调用他们的参数。
	- 您还可以制定返回参数并以正常方式设置所需属性
	- mock的patch()装饰器，用于处理测试范围内的修补模块和类级属性

## 希望得到返回数据
- 设置返回值和属性
- mock object对象的返回值
```python
mock = Mock()
mock.return_value = 3
mock()
```
- methods具体方法返回值
```python
mock.something.return_value = 3
mock.something()
```
- attribute setting 属性的设置
```python
mock.x = 5
mock.x
```
- 通过构造方法-传参的方式
```python
mock = Mock(return_value = 3)
mock()
```
- 多次不同返回值及顺序
```python
Mock.side_effect = (200,404,302,500)
```
## 希望跟踪多个方法是否被调用和断言
```python
# 跟踪是否被调用
mock_calls
# 断言是否调用的这个参数		
assert_called_with()
# 断言是否只调用一次		
assert_called_once_with()
```
## 对已有的类的实例使用patch临时改变返回值
```python
# 导入需要测试的类，mock库，patch
from test import testClass
from unittest.mock import patch

# some_function方法是调用要测试的实例
def some_function():
    ins = testClass.method()  # 调用测试类中的模块   
    return ins.method()

# 使用with patch方法将要mock的方法写出来，加了返回值和方法返回值，是拦截了命名空间先调用了mock
with patch('test.testClass.method') as mock:
    ins = mock.return_value
    ins.method.return_value = 'result'
    result = some_function()
    assert result == 'result'
```
## mock扩展应用-性能测试解决方案之一
- 进行自服务器的压力测试方案
- 直接使用线上的后端服务进行压测
	- 优点：近线上状态，代价极小
	- 缺点：线上子服务的稳定性，数据统计，引入脏数据等
- 部署完整的后端测试环境、
	- 优点：与线上隔离；测试结果基本与线上环境一致，测试结果相对准确
	- 缺点：部署成本极高，要保证子服务性能会造成的资源浪费
- 部署部分子服务
	- 优点：与线上隔离；部署成本相对较小
	- 缺点：测试结果有出处，后端性能可能是瓶颈
- 使用测试平台mock后端接口数据
	- 优点：与线上隔离；
	- 缺点：mock平台一般性能较弱，测试结果有出入；mock平台的逻辑规则会有一定学习成本（可以通过django写的mock服务）
- 使用nginx cache mock子服务返回内容：
	- 优点：与线上隔离子服务返回内容与线上一致；可保证后端性能不是瓶颈
	- 缺点：必须使用固定的一组请求（请求数量在几万的量级没有问题）

## 爬坑
- @patch 的路径一定要完整