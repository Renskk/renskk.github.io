---
title: Appium参数
date: 2018-06-10 18:31:52
tags:
---
## Appium安装

下载地址：https://github.com/appium/appium-desktop/releases/



## Appium参数

```python
desired_caps = {}  				# 定义webdriver的兼容性设置字典对象
desired_caps['platformName'] = 'Android'  	# 指定测试Android平台
desired_caps['platformVersion'] = version  	# 指定移动端的版本号
desired_caps['deviceName'] = 'Appium' 		# 指定设备名称
# desired_caps['automationName'] = 'uiautomator2'
desired_caps['appPackage'] = 'com.mobivans.onestrokecharge'  # 指定要启动的包
desired_caps['appActivity'] = 'com.stub.stub01.Stub01'  # 指定启动的主类程序
desired_caps['unicodeKeyboard'] = 'True'  	# 使用中文输入法
desired_caps['udid'] = udid 		# 指定模拟器设备编号(adb devices输出结果)
desired_caps['noReset'] = 'True'  		# 不重置应用程序的状态，默认为false
```
Appium内置的配置参数非常多，主要分为两大类。一类是命令行启动参数，主要用于在命令行启动Appium服务器的时候指定的参数。一类是脚本开发时的兼容性设置参数，如前一节内容中的desired_caps字典对象指定的参数值。两种类别的参数有些是可以互相代替的，比如在启动命令中未指定，而通过字典对象在脚本中指定，结果一样。先来看看两种类型的参数中比较重要的参数。
命令行启动参数
- -a 绑定的IP地址：如appium –a 192.168.1.5，默认不指定的情况下为localhost，也即是127.0.0.1，适用于为本机脚本提供连接。当然，我们也可以让测试脚本连接远程Appium服务器。
- -p 服务器端口号：Appium服务器启动时绑定的端口号，用于脚本的通信，默认值为4723。此处需要注意的是，一个端口号只能服务于一台移动设备，如果我们需要同时对多台针对设备进行测试，那么则需要启动多个Appium服务器，每一个服务器实例需要绑定不同的端口号。
- -bp 连接移动端设备的端口号，即Bootstrap端口，默认值为4724。如果需要连接多台移动设备，则需要启动不同端口的Appium服务器并且指定不同的设备端口号。即需要单独为不同的设备，启动不同端口的Appium服务器，并且指定不同的Bootstrap端口号，否则会导致冲突。
- --app 应用程序路径：指定调试模式下的iOS应用或标准的Android系统的APK应用程序的路径，通常情况下不建议在启动时指定，而是在测试脚本中通过字典对象来指定应用程序路径。如果是针对非调试模式下的iOS设备，则对应参数为--ipa。如果已经在手机上安装了相应的应用，则勿需指定，只需要通知移动端代理启动应用即可。
- --app-pkg：指定要测试的应用程序的主包名，与测试脚本中指定的功能一致。该参数仅Android端适用。
- --app-activity：指定要测试的应用程序的主类名，与测试脚本中指定的功能一致。该参数仅Android端适用。
- -U 设备编号：在启动时直接指定当前服务器连接到哪个设备终端。其编号可以从命令“adb devices”的输出列表中获取。一台设备，当连接上电脑后一定有一台唯一的编号。也可以通过参数“--udid”指定，二者效果一致。
- --session-override：当连接过程出现Session冲突的时候，允许被覆盖。目前使用情况较少。
- --full-reset：完全重置被测试应用程序的状态，包括将测试应用程序全部删除。
- --no-reset：不重置状态，不删除应用。
- -g 日志文件：将Appium运行过程的日志输出到指定的日志文件中，便于后续查看。通常情况下，在正式进行测试的过程，我们最好将日志输出到文件，便于永久保存和后续分析。该参数也可以使用“--log”代替。
- --log-timestamp：在终端输出里显示时间戳，便于更好地知道日志输出的时间。
- --log-level：在终端里输出的日志级别，可以设置为debug，info，warn，error等级别。
- --device-name：指定待测试的移动设备的名称，也可在测试脚本中指定。
- --platform-name：指定移动设备对应的平台的名称，如Android或iOS，也可在测试脚本中指定。
- --platform-version：指定移动设备系统对应的版本号，如4.4.2，也可在测试脚本中指定。
比如可以通过以下命令启动Appium，来指定IP地址，端口号，Bootstrap端口号，设备编号，不重置状态，输出时间戳在日志中，覆盖Session连接状态，并将日志信息输出到指定的日志文件中进行永久保存：appium -a 127.0.0.1 -p 4723 –bp 4724 –U 127.0.0.1:62001 --no-reset --session-override --log-timestamp --log D:\appium.log


## 测试脚本字典参数
(platformName、platformVersion、deviceName、app、browserName、udid、noReset、appActivity、appPackage、unicodeKeyboard)
在测试脚本中的字典参数有很多与命令行参数功能类似，只是参数名称不一样，现列举如下：
- automationName：指定自动化测试引擎，可以是Appium (默认) 或 Selendroid。如果是较新的Android版本，如6.0以上，则必须明确指定automationName=’ uiautomator2’。
- platformName：指定要测试的手机操作系统，如：iOS，Android或FirefoxOS。
- platformVersion：移动操作系统版本，如4.4.2。
- deviceName：使用的手机类型或模拟器类型。在iOS中，必须使用“instruments -s devices”命令得到的设备编号。
- app：指定待测试应用程序。
- browserName：如果是针对手机上的浏览器应用进行测试，需要指定其浏览器名称。在iOS上可用“Safari”，在Android上可指定“Chrome”，“Chromium”或“Browser”。
- newCommandTimeout：设置命令超时时间，单位：秒。达到超时时间仍未接收到新的命令时Appium 会假设客户端退出然后自动结束会话。
- autoLaunch：Appium是否需要自动安装和启动应用，默认值为true。
- udid：连接的移动设备的唯一设备标识
- autoWebview：直接转换到 WebView 上下文。 默认值为false。
- noReset：不要在会话前重置应用状态，默认为false。
- fullReset：在会话结束后自动清除被测应用，默认为false。
- appActivity：应用包中启动的 Android Activity 主类名称。它通常需要在前面添加“.”。
- appPackage：想运行的Android应用程序的主包名。
- deviceReadyTimeout：设置等待一个模拟器或真机准备就绪的超时时间。
- unicodeKeyboard：设置使用Unicode输入法，这样才能支持中文输入。
- resetKeyboard：在使用了unicodeKeyboard参数后，对其进行重置，还原为默认设置。
完整的参数列表，访问Appium官方网站查阅：http://appium.io/docs/en/writing-running-appium/caps/
