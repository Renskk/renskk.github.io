---
title: docker基础
date: 2019-04-23 12:27:34
tags:
---
# docker基础
## 基础命令
* **启动容器：**
```shell
$ docker run image [command] [ARG]
```
* **启动交互式容器：**
```shell
$ docker run -i -t IMAGE /bin/bash 
$ docker run --name mysqltest -i -t centos:7 /bin/bash
```
* **查看容器：**
```shell
$ docker ps [-a] [-l] # -a 查看所有容器信息  -l 列出最新容器
$ docker inspect[] # 查看容器信息
```

## 自定义容器名

```shell
$ docker run name = 自定义  -i -t IMAGE /bin/bash
```

## 重新启动停止的服务

```shell
$ docker start [-i] 容器名
```

## 删除容器

```shell
$ docker rm -a 
```

## 以守护形式运行容器

```shell
CTRL + Q   OR   CTRL + P
```

## 启用守护式容器

```shell
$ docker run -d 镜像名 [command] [ARG]
```

## 查看容器日志

```shell
$ docker logs [-f] [-t] [--fail] 容器名
	-f	-- follows = true | fales 默认为fales
	-t	-- timestamps = true | fals 默认为fales
	--fail = 'all'
```

## 查看容器进程

```shell
$ docker top 容器名
```

## 运行的容器中启用新的进程

```shell
$ docker exec [-d] [-i] [-t] 容器名 [commend] [ARG]
```

## 停止容器

```shell
$ docker stop 容器名
$ docker kill 容器名
```

## 设置容器的端口映射

```shell
# 大写P表示随机选择一个端口映射到容器内部开放的网络端口上
$ docker run -P -i -t ubuntu /bin/bash
# 小写p指定要映射的端口
$ docker run -p 80 -i -t ubuntu /bin/bash
$ docker run -p 8080:80 -i -t ubuntu /bin/bash
$ docker run -p 0.0.0.0:8080:80 -i -t ubuntu /bin/bash
# 绑定本机的任意端口到容器的80端口，随机分配一个端口
$ docker run -p 0.0.0.0::80 -i -t ubuntu /bin/bash
```

# docker 镜像

##　列出镜像

```shell 
$ docker images [options] [REFOSITORY]
	-a	显示所有镜像
	-f	过滤条件
	-q	只显示images veid
```

##　查看镜像信息

```shell
$ docker inspect 容积或镜像ID 
```

## 删除镜像

```shell
$ docker rmi [OPTION] IMAGE [IMAGE]
	-f --force = false
	-no -prane = fales
```

## 删除所有镜像

```shell
$ docker rmi -f image_id
```

## 搜索镜像

```shell
$ docker search IMAGE
```

## 拉取镜像

```shell
$ docker pull [OPTION] NAME [:TAG]
# 例如拉取ubuntu:16.04镜像
$ docker pull ubuntu:16.04
```

### docker问题汇总

```

```

