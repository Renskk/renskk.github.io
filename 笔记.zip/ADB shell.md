---
title: ADB常用命令
date: 2018-06-03 12:27:34
tags:
---

# adb shell 命令
```shell
adb devices				# 列出以连接的设备
adb shell 				# 连接终端
adb root 				# 进入root
adb remount				# 挂载手机
adb install /test.apk			# 安装test应用
adb uninstall [packageName]  eg:adb uninstall com.miui.calculator 
# 卸载应用程序
adb reboot bootloader			# 进入fastboot模式
adb reboot recovery			# 进入recovery模式
adb shell getprop			# 获取Android的系统属性
adb push c:/test.apk /mnt/sdcard	# 将电脑C盘的test.apk push到手机端
adb pull /mnt/sdcard/test.apk c:/	# 将手机端的test.apk pull到电脑端
adb shell pm list package -f 		# 获取手机内所有APK对应的路径和包名
adb logcat > D:/log.txt			# 将获取的log日志放入D:/log.txt
adb shell ps				# 查看进程
adb shell top -m 5			# CPU占用前5名
adb shell /system/app			# 查看所有的APP文件
adb shell dumpsys activity 		# 查询AMS服务相关信息
adb shell dumpsys window 		# 查询WMS服务相关信息
adb shell dumpsys cpuinfo 		# 查询CPU情况
-----------------------------------------------------------------
# adb手机操作
adb shell input keyevent 3		# 模拟点击home键
adb shell input keyevent 4		# 模拟点击back键
adb shell input text “001”		# 输入001
adb shell input tap 250 250		# 点击坐标为（250，250）的位置
adb shell input swipe 250 250 300 300	# 滑动屏幕由（250，250）到（300，300）
-----------------------------------------------------------------
adb shell dumpsys meminfo [packageName]			# 查询内存情况
adb logcat -b erents |findstr am_activity_launch_time	# 查看APP启动时间
adb shell cat /sys/class/leds/lcd-backlight/brighthess	# 查看当前手机屏幕亮度
adb shell screencap -p /sdcard/screen.png		# 截图保存
adb shell screenrecord --time-limit 10 /sdcard/demo.mp4 # 录制10秒的视频
adb shell dumpsys activity | grep mFocusedActivity		
# 获取app的 appPackage和appActivity
adb shell am start -n [packageName]/[packageName].[activityName]# 启动APP
adb shell am start -n com.miui.calculator/.cal.CalculatorActivity 
# 命令行启动APP应用程序计算器
aapt dump badging 			# 绝对路径/XX.apk 查询apk的包名和类名
adb shell am start -n com.miui.calculator/
com.miui.calculator.cal.CalculatorActivity
# 打开一笔记账应用程序：
adb shell am start -n com.mobivans.onestrokecharge/com.stub.stub01.Stub01 	
adb kill-server   # 停止adb服务器
adb start-server  # 启动adb服务器
adb shell pm list packages 	# 查询系统的应用程序包名；
adb shell pm list packages -s 	# 指定查询系统自带的包名；
adb shell pm list packages -3 	# 查询第三方程序的包名  
adb shell ps | findstr adbd 	# 查询运行在 Android 设备上的 adb 后台进程
adb bugreport > d:\bugreport.log # 打印缺陷日志报告至指定文件
adb shell screencap -p /data/local/tmp/test001.png # 屏幕截图至指定路径
adb shell getprop ro.serialno # 获取设备序列号
adb get-serialno # 获取设备ID号
adb shell monkey -p com.miui.calculator -s 999 --throttle 500 -v-v-v 300 
# 每隔500毫秒执行一个事件，按随机种子ID为999，执行300次,显示详细信息
adb shell monkey --pkg-whitelist-file /data/local/tmp/file.txt 1000
# (需要提前将文件准备好)；准备白名单/黑名单的清单文件--上传至手机指定路径下--执行命令
```