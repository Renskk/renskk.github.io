---
title: Bean Shell基础
date: 2018-12-11 12:27:34
tags:
---

## 什么是Bean Shell
- BeanShell是一种完全符合Java语法规范的脚本语言，并且有拥有自己的一些语法和方法。
- BeanShell是一种松散类型的脚本语言（这点和JS）类似。
- BeanShell是用Java写成的，一个小型的、免费的、可下载的、嵌入式的Java源代码解释器，具有对象脚本语言特性，非常精简的解释器。
- BeanShell执行标准的Java语句和表达式，另外包括一些脚本命令和语法。

## Jmeter有哪些Bean Shell
- 定时器：　　BeanShell Timer
- 前置处理器：BeanShell PreProcessor
- 采样器：　　BeanShell Sampler
- 后置处理器：BeanShell PostProcessor
- 断言：　　　BeanShell断言
- 监听器：　　BeanShell Listener

## BeanShell的用法

## BeanShell常用内置变量
JMeter在它的BeanShell中内置了变量，用户可以通过这些变量与JMeter进行交互，其中主要的变量及其使用方法如下:
- log：写入信息到jmeber.log文件，使用方法：log.info(“This is log info!”);

- ctx：该变量引用了当前线程的上下文，使用方法可参 org.apache.jmeter.threads.JMeterContext。

- vars - (JMeterVariables)：操作jmeter变量，这个变量实际引用了JMeter线程中的局部变量容器（本质上是Map），它是测试用例与BeanShell交互的桥梁，常用方法：
　　 　     a) vars.get(String key)：从jmeter中获得变量值
　　  　b) vars.put(String key，String value)：数据存到jmeter变量中
- props - (JMeterProperties - class java.util.Properties)：操作jmeter属性，该变量引用了JMeter的配置信息，可以获取Jmeter的属性，它的使用方法与vars类似，但是只能put进去String类型的值，而不能是一个对象。对应于java.util.Properties。 
　　　　a) props.get("START.HMS");　注：START.HMS为属性名，在文件jmeter.properties中定义 
　　　　b) props.put("PROP1","1234"); 
- prev - (SampleResult)：获取前面的sample返回的信息，常用方法：
　　　　a) getResponseDataAsString()：获取响应信息
　　　　b) getResponseCode() ：获取响应code
- sampler - (Sampler)：gives access to the current sampler

## beanshell-usage
1. 添加http请求，数据参数化
2. 添加beanshellpreprcessor
```shell
vars.put("user","admin123");//定义请求数据中的参数:用户名
vars.put("pass","admin123");//定义请求数据中的参数：密码
save=vars.put("save","false");//定义请求数据中的参数：是否保存登录信息
```
3. 添加beanshell断言
```shell
String username=vars.get("user");//获取参数中的用户名信息
log.info("用户名:"+username);//打印用户名
```
4. 添加beanshellpostprocessor
```shell
resp_text=prev.getResponseDataAsString();//获取请求的响应结果
log.info(resp_text);//打印响应结果
log.info(resp_code);//打印响应代码
resp_mes=prev.getResponseMessage();//获取响应结果的消息
log.info(resp_mes);//打印响应结果的消息
pro=props.get("START.HMS");//获取START.HMS的属性信息
log.info(pro);//打印START.HMS的属性信息
```
5. 自定义函数：添加beanshell sample，编写脚本
6. 添加debug Sample,用于调试脚本

